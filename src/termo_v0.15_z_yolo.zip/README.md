# Analizator temperatury człowieka z kamery termowizyjnej (wersja 0.1)

Program wczytuje zdjęcie lub film w dwóch wersjach naraz (kolorowej z paletą temperatur
oraz czarno-białej), zamienia je na mapę temperatur, wykrywa sylwetkę i twarz i podaje:

* **średnią temperaturę powierzchni ciała** (wszystkie piksele sylwetki),
* **temperaturę czoła**: mediana, średnia, percentyl 90 i maksimum ciepłej skóry w obszarze czoła;
  w filmie jest to mediana z wszystkich klatek, w których znaleziono twarz.

## Instalacja

```bash
pip install -r requirements.txt     # Python 3.9+, OpenCV 4.x (w 4.x są modele Haara do twarzy)
```

## Użycie

```bash
# zdjęcie: dwa pliki
python termo_analyzer.py --color kolor.jpg --gray szary.jpg --tmin 20 --tmax 40 --out wynik

# film: dwa pliki (klatki czytane równolegle)
python termo_analyzer.py --color kolor.mp4 --gray szary.mp4 --tmin 20 --tmax 40 --out wynik

# jeden plik z obiema wersjami obok siebie (h = lewo/prawo, v = góra/dół)
python termo_analyzer.py --combined oba.png --split h --out wynik

# dane radiometryczne 16-bit (np. FLIR w centykelwinach)
python termo_analyzer.py --gray surowe.tiff --gray-gain 0.01 --gray-offset -273.15
```

Wyniki w katalogu `--out`: `adnotacje.png` / `adnotacje.mp4` (kontur ciała na zielono,
twarz na turkusowo, czoło na czerwono), `raport.json`, dla zdjęcia także `mapa_temperatury.npy`
(macierz °C), dla filmu `klatki.csv`.

Ważniejsze opcje: `--palette` (auto | bar | iron | rainbow | jet | inferno | hot | turbo | gray),
`--forehead-metric` (mediana | srednia | p90 | max), `--emissivity 0.98`, `--core-offset 1.0`
(szacunek temperatury wewnętrznej), `--body-tmin 28`, `--yunet model.onnx` (lepszy detektor twarzy
OpenCV YuNet, jeśli pobierzesz model), `--step N` (co N-ta klatka filmu).

## Kamera FLIR T620 (T62101) – dane radiometryczne

Zdjęcia JPG z FLIR T620 zawierają ukryte surowe dane detektora (16 bit) i stałe kalibracji
kamery. Program sam to wykrywa i liczy temperaturę każdego piksela wzorem FLIR (tak jak FLIR Tools),
więc **nie trzeba podawać skali ani drugiego obrazu**:

```bash
python termo_analyzer.py --color FLIR0123.jpg --out wynik
python termo_analyzer.py --color nagranie.seq --step 5 --out wynik      # nagranie radiometryczne
```

Emisyjność, odległość, temperatura odbita, powietrza i wilgotność są brane z ustawień zapisanych
w pliku przez kamerę. Można je nadpisać: `--emissivity 0.98 --distance 1.0 --reflected-temp 22
--atm-temp 22 --humidity 40`. Dla skóry właściwa emisyjność to 0.98, a kamera fabrycznie ma
zwykle 0.95, co zawyża wynik o ok. 0.3–0.5 °C. Nagrania `.csq` (skompresowane) nie są jeszcze obsługiwane.
`--tmin/--tmax` służą wtedy tylko do kolorowania podglądu.

Uwaga: zdjęcie musi pochodzić prosto z kamery. Po edycji w innym programie lub wysłaniu
komunikatorem dane radiometryczne zwykle znikają i zostaje tylko obraz w palecie.

## Skala odczytywana z obrazu i YOLO (wersja 0.4)

* **Skala min/max**: pola „Min/Max skali” można zostawić puste. Program znajduje pasek skali,
  odczytuje liczby przy jego końcach (np. 32.6 i 19.9) i od nich liczy temperatury. Odczytane
  wartości są wypisane w wynikach, żeby można je było sprawdzić. Gdy odczyt się nie uda, program
  przyjmuje 20–40 °C i wyraźnie o tym ostrzega. Dla zdjęć radiometrycznych FLIR skala jest brana
  z danych kamery. Napisy kamery (czarne ramki z białym tekstem) są wykluczane z pomiaru.
  Sprawdzone na zdjęciu FLIR2282.jpg (FLIR T420): temperatury z kolorów i odczytanej skali różnią się
  od danych radiometrycznych kamery średnio o 0.2–0.3 °C.
* **YOLO**: twarz jest szukana najpierw modelem YOLOv8n-face (`yolov8n-face.onnx`, uruchamiany przez
  onnxruntime), potem metodą Haar, a na końcu z kształtu ciepłej sylwetki. Model leży obok programu
  albo jest wbudowany w .exe. Źródło: github.com/akanametov/yolo-face (wydanie 1.0.0), licencja AGPL-3.0
  (Ultralytics) – bez ograniczeń do własnego użytku; przy rozpowszechnianiu programu obowiązują jej warunki.
  Model był uczony na zwykłych zdjęciach (WIDER FACE), więc na termogramach działa gorzej niż na zdjęciach.
  Opcje: `--yolo ścieżka.onnx`, `--no-yolo`.

## Ostrzeżenie o braku modelu YOLO (wersja 0.15)

Jeśli exe zbudowano bez pliku `yolov8n-face.onnx` (np. po rozpakowaniu paczki do nowego podfolderu), program
nie ocenia pewności twarzy i w trybie „co 1 s” nie robi żadnego pomiaru. Okienko oceny świeci wtedy na
pomarańczowo: „Brak modelu YOLO – brak pomiarów”. Rozwiązanie: położyć `yolov8n-face.onnx` obok
`build_exe.bat` i zbudować exe ponownie (albo obok `AnalizatorTermo.exe`).

## Pewność twarzy w każdej sekundzie (wersja 0.14)

Kafelek „Czas filmu” pokazuje pewność twarzy w bieżącej sekundzie filmu: najwyższą pewność YOLO spośród
przeanalizowanych klatek tej sekundy, także gdy jest poniżej progu (wtedy z dopiskiem „za mało”).
Tabela „Sekunda po sekundzie” podaje ją dla sekund bez pomiaru („za mało pewna · 0.45”), a `sekundy.csv`
ma kolumnę `pewnosc_max`.

## Pomijanie klatek bez twarzy (wersja 0.13)

Gdy w analizowanej klatce nie ma pewnej twarzy (brak twarzy albo pewność YOLO poniżej progu), program
pomija kolejne `--pomin-bez-twarzy` klatek (domyślnie 3; w oknie „Pomiń kl. bez twarzy”, 0 = sprawdzaj
każdą klatkę) i dopiero wtedy szuka twarzy znowu. Przyspiesza to fragmenty filmu bez osoby w kadrze,
ale pomiar może nastąpić do kilku klatek później, niż twarz pojawiła się w kadrze.

## Ostatni pomiar w czasie bez pomiaru, poprawka zdjęć (wersja 0.12)

Gdy w danej sekundzie filmu nie ma pewnej twarzy, górny kafelek „Najcieplejszy punkt twarzy” pokazuje
ostatni wcześniejszy pomiar (z podpisem, kiedy był), ale tylko jeśli był nie dawniej niż 5 s temu
(pole „Pokaż ost. pomiar [s]”, 0 = nie pokazuj). Przy dłuższej przerwie kafelek pokazuje „–”.

Poprawka: w wersjach 0.9–0.11 analiza zdjęcia FLIR kończyła się błędem („too many values to unpack”),
gdy YOLO znalazło twarz na zdjęciu wizyjnym zapisanym w pliku JPG.

## Okienko alarmu temperatury (wersja 0.11)

Pod kafelkami jest okienko oceny. Świeci na zielono („Temperatura w normie”), a na czerwono
(„WYSOKA TEMPERATURA”), gdy co najmniej 2 pomiary najcieplejszego punktu twarzy są powyżej 37,5 °C.
W filmie pomiar to wynik jednej sekundy, w zdjęciu jest jeden pomiar (wtedy wystarczy, że on przekroczy próg).
Próg i liczbę pomiarów zmienia się w panelu „Alarm temperatury”; ocena zmienia się od razu, bez ponownej
analizy. Jeśli któryś pomiar jest na końcu skali kamery („≥”), okienko o tym przypomina – prawdziwa
temperatura może być wtedy wyższa niż odczytana.

## Pomijanie klatek po pomiarze (wersja 0.10)

Żeby analiza filmu trwała krócej, po każdym pomiarze (klatka z twarzą rozpoznaną przez YOLO z pewnością
co najmniej `--pewnosc`) program pomija kolejne `--pomin` klatek (domyślnie 30, czyli ok. 1 s przy 30 kl./s;
w oknie „Pomiń kl. po pomiarze”). Pominięte klatki nie są analizowane – trafiają tylko do filmu wynikowego
z wynikiem ostatniego pomiaru. Po przerwie program analizuje klatki po kolei aż do następnej pewnej twarzy
i ta klatka staje się kolejnym pomiarem. `--pomin 0` przywraca analizę każdej klatki (wersja 0.9:
najpewniejsza twarz w każdej sekundzie). Na FLIR2304 analiza skróciła się z ok. 47 s do 17 s
(pominięto 150 z 198 klatek).

## Jeden pomiar na sekundę przy pewnej twarzy (wersja 0.9)

Domyślny tryb filmu (`--tryb-sekundy pewna`, w oknie „Pomiar w filmie: co 1 s”):
w każdej sekundzie filmu program wybiera **jedną klatkę** – tę, w której YOLO rozpoznało twarz
z największą pewnością – i podaje najcieplejszy punkt twarzy tylko z niej. Klatka musi mieć pewność
co najmniej `--pewnosc` (domyślnie 0.6, w oknie „Min. pewność twarzy”). Jeśli w danej sekundzie
żadna klatka jej nie osiąga (twarz z profilu, częściowo poza kadrem, tylko śledzona), sekunda zostaje
bez wyniku. Twarze znalezione przez Haar, śledzenie albo sylwetkę nie mają oceny pewności, więc nie są
brane pod uwagę. Tryb `srednia` (dawne zachowanie) liczy średnią ze wszystkich klatek sekundy z twarzą.

`sekundy.csv` ma kolumny `klatka_pomiaru` i `pewnosc_twarzy`, a `klatki.csv` – `pewnosc_twarzy` każdej klatki.
Podsumowanie filmu to średnia z wyników sekund.

## Lepsze wykrywanie twarzy YOLO na samej termowizji (wersja 0.8)

YOLO uczono na zwykłych zdjęciach, więc na termogramie program pomaga mu kilkoma krokami
(kolejno, do pierwszego trafienia):
1. obraz w wąskim oknie temperatur wokół skóry (ok. 8 °C poniżej najcieplejszych miejsc ciała),
   z wyrównaniem kontrastu – widać oczy, nos, usta i włosy (`yolo-okno`);
2. oryginalna klatka w palecie kolorów kamery (`yolo-paleta`);
3. przybliżenie okolicy głowy znalezionej z sylwetki – dla małej, dalekiej twarzy (`yolo-zoom`);
4. dotychczasowe próby (`yolo`, potem Haar);
5. w filmie: gdy YOLO zgubi twarz na chwilę (do 15 klatek), zostaje jego ostatnia ramka, o ile
   dalej leży na ciepłej skórze (`yolo-sledzenie`); dopiero potem Haar i sylwetka.

Dla twarzy próg pewności YOLO na termowizji to 0.25 – fałszywe trafienia odrzuca kontrola, że
ramka leży na ciepłej skórze w obrębie sylwetki. `--yolo-prosty` wyłącza te zmiany (jak w 0.7).
`python ocena_twarzy.py film1.mp4 film2.mp4` porównuje obie wersje na nagraniach.

Wyniki filmu: tylko klatki, w których widać twarz. W filmie z YOLO nie ma już zastępczej „głowy
z sylwetki” – przy tyle głowy, profilu albo ręce przed kamerą wskazywała włosy lub ubranie.

**Pomiar czoła został usunięty** (na życzenie użytkownika). Program podaje: ramkę twarzy,
najcieplejszy punkt twarzy (w filmie średnia ze wszystkich klatek sekundy) i średnią temperaturę
ciała. Opisy czoła w starszych sekcjach poniżej są nieaktualne.

## Film z automatyczną skalą kamery i średnie z każdej sekundy (wersja 0.7)

- Kamera z automatyczną skalą (np. FLIR T420 nagrywająca .mp4) zmienia liczby przy pasku w trakcie
  nagrania. Program czyta je teraz w **każdej klatce** i liczy temperaturę z aktualnej skali.
  Zmiana o więcej niż 15 °C musi się powtórzyć w dwóch kolejnych klatkach (ochrona przed błędem OCR).
- Jeśli w pierwszej klatce pasek skali jest nieczytelny (np. jasna ręka dotyka paska), program
  przed analizą szuka w filmie klatki z czytelnym paskiem i bierze z niej położenie paska i paletę.
  Liczby czyta potem przy tym pasku w każdej klatce. Wcześniej cały film był liczony w domyślnej
  skali 20–40 °C, co dawało fałszywe 40 °C na twarzy.
- Klatki, w których skali nie udało się jeszcze odczytać, nie wchodzą do średnich.
- **Wyniki zmieniają się co sekundę**: czoło, najcieplejszy punkt twarzy i ciało to **średnia ze
  wszystkich klatek danej sekundy** – w oknie programu (kafelki, tabela, wykres), w filmie
  `adnotacje.mp4`, w wydruku i w nowym pliku `sekundy.csv`.
- Gdy twarz ma kolor końca skali (np. biały w palecie rainbow), wynik jest oznaczony „≥” – kamera
  ustawiła górną granicę skali na twarzy, więc prawdziwa temperatura może być wyższa.
- `klatki.csv` ma nowe kolumny `skala_min`, `skala_max` (skala użyta w danej klatce) i `koniec_skali`.

## Okno programu, film i najcieplejszy punkt twarzy (wersja 0.6)

* **Nowe okno** (ciemny motyw): po lewej pliki i ustawienia, u góry kafelki z wynikami (czoło,
  najcieplejszy punkt twarzy, średnia temperatura ciała, czas filmu), w środku podgląd wyniku.
* **Odtwarzacz filmu z wynikami**: po analizie filmu wynik (adnotacje.mp4) odtwarza się w oknie.
  Przyciski odtwórz/pauza, klatka w przód/w tył, suwak, prędkość 0.25×–2×. Kafelki pokazują wartości
  dla bieżącej klatki i sekundy filmu.
* **Najcieplejszy punkt twarzy**: w każdej klatce program szuka najcieplejszego miejsca w całej ramce twarzy
  (zwykle wewnętrzny kącik oka) i zaznacza je różowym krzyżykiem. Pojedyncze zaszumione piksele są pomijane
  (wygładzenie 3×3 przy szukaniu położenia).
* **Poprawki 0.6.1**: wynik jest zawsze pokazywany na obrazie termowizyjnym (powiększonym), także gdy twarz
  była szukana na zwykłym zdjęciu. Twarz musi być ciepła (co najmniej 35% skóry 30–42 °C) i leżeć na sylwetce,
  więc trafienia na ścianie są odrzucane, a przy kilku kandydatach wygrywa najbardziej „skórny”, nie największy.
  Temperatura najcieplejszego punktu to średnia z okna 3×3 wokół niego, a gdy punkt dochodzi do górnego końca
  skali, program pisze „≥” i ostrzega, że prawdziwa wartość może być wyższa (wtedy wykres jest płaski).
  Kolor jest teraz zamieniany na temperaturę dokładnie (interpolacja między sąsiednimi kolorami palety zamiast
  siatki 32×32×32): na obrazie testowym błąd spadł z 0.09 do 0.02 °C, a liczba rozróżnianych poziomów wzrosła
  z 63 do 175. W filmie z kamery z automatyczną skalą liczby przy pasku są odczytywane ponownie, gdy się zmienią,
  więc każda klatka jest liczona z właściwego zakresu.
* **Sekunda po sekundzie**: zakładka z tabelą (czoło – mediana z klatek danej sekundy, najcieplejszy punkt –
  maksimum w danej sekundzie, ciało, metoda wykrycia twarzy) i wykres obu temperatur w czasie. Kliknięcie
  w wykres lub wiersz tabeli przewija film do tego momentu. Te same dane są w `klatki.csv`
  (kolumny `czas_s`, `temp_czola`, `najcieplejszy_punkt_twarzy`) i w `raport.json`.

## Zdjęcie zwykłe (wizyjne) większe od termogramu (wersja 0.5)

Zdjęcie z kamery wizyjnej (np. 2048×1536) ma szersze pole widzenia niż obraz termowizyjny
(np. 320×240), który jest jego wycinkiem. Program:
1. liczy temperaturę tylko z obrazu termowizyjnego (albo z danych radiometrycznych FLIR),
2. sam odnajduje, który fragment zdjęcia odpowiada termogramowi: sprawdza wiele skal i położeń,
   porównując kształty (np. ciepła sylwetka jest na zdjęciu ciemna lub jasna), a potem doprecyzowuje wynik.
   W raporcie podaje, jaką część szerokości zdjęcia zajmuje termogram, gdzie leży i jak dobra jest zgodność
   (powyżej ok. 0.5 = pewne dopasowanie),
3. szuka twarzy na zdjęciu (YOLO działa tam lepiej niż na termogramie) i bierze tylko twarze leżące
   w polu widzenia kamery termowizyjnej,
4. rysuje wynik na całym zdjęciu, a szarą ramką zaznacza pole widzenia kamery termowizyjnej.

**Zdjęcia JPG z FLIR T420** zawierają już w środku zdjęcie wizyjne 2048×1536 oraz dane, gdzie leży na nim
termogram (PiP: Real2IR i przesunięcie). Wystarczy więc wczytać sam plik FLIR, a program użyje
osadzonego zdjęcia. Sprawdzone na FLIR2282.jpg: termogram zajmuje 47% szerokości zdjęcia, a wynik
dopasowania obrazów zgadza się z danymi kamery z dokładnością do kilkunastu pikseli zdjęcia.

Kolejność plików w polach nie ma znaczenia. Jeśli dopasowanie się nie uda, program ostrzega i zakłada ten sam kadr.

## Jak to działa

1. **Kolor → temperatura.** Program szuka paska skali przy krawędzi obrazu i odczytuje z niego
   paletę. Bez paska dobiera najlepiej pasującą paletę wbudowaną. Każdy piksel dostaje najbliższy
   kolor palety (w przestrzeni Lab), a pozycja w palecie jest przeliczana liniowo na °C w zakresie
   `--tmin`..`--tmax`. Piksele niepasujące do palety (napisy, celowniki) są pomijane.
2. **Szarość → temperatura.** Jasność 0..255 (lub 0..65535) liniowo na `--tmin`..`--tmax`.
   Jeśli obraz jest „black-hot”, program sam go odwraca (ujemna korelacja z wersją kolorową).
3. **Połączenie.** Gdzie obie wersje są wiarygodne, brana jest średnia; pod napisami tylko szarość.
   `roznica_kolor_szary` w raporcie to kontrola spójności: powyżej ~0.5 °C znaczy, że coś się
   nie zgadza (zły zakres, paleta albo przesunięte kadry).
4. **Ciało.** Piksele w zakresie `--body-tmin`..`--body-tmax` (domyślnie 28..42 °C), oczyszczone
   morfologicznie; małe plamy są odrzucane.
5. **Twarz.** Kolejno: YuNet (jeśli podano model), Haar frontalny (obraz zwykły i odwrócony),
   Haar profilowy, a jeśli nic nie znajdzie, to heurystyka sylwetki: głowa to górna część
   największej ciepłej plamy, nad miejscem, gdzie sylwetka rozszerza się w barki. Dzięki temu twarz
   (głowa) jest znajdowana prawie zawsze, gdy człowiek jest w kadrze. Fałszywe detekcje
   w zimnych miejscach są odrzucane.
6. **Czoło.** W ramce twarzy szukana jest linia włosów (włosy są chłodniejsze); czoło to pas pod
   nią, kończący się nad brwiami. Z tego obszaru brana jest cieplejsza część pikseli (bez włosów,
   okularów, tła), a z niej mediana, średnia, p90 i maksimum.

## Założenia do potwierdzenia

| # | Założenie | Co jest potrzebne |
|---|-----------|-------------------|
| Z1 | Skala liniowa, zakres podany ręcznie (domyślnie 20–40 °C) | model kamery albo zakres widoczny na obrazie; OCR liczb przy pasku można dodać |
| Z2 | Pasek skali przy krawędzi, gorący koniec jaśniejszy | przykładowy plik |
| Z3 | Szary obraz to white-hot albo black-hot, 8 lub 16 bit | informacja, czy kamera eksportuje dane radiometryczne |
| Z4 | Wersja kolorowa i szara mają ten sam kadr | przykładowa para plików |
| Z5 | Wynik to temperatura powierzchni skóry; temp. wewnętrzna jest zwykle o 0.5–1.5 °C wyższa | decyzja, czy dodawać stałą korekcję |

## Dokładność

Na danych syntetycznych (czoło 35.8 °C, szum 0.12 °C) wynik to 35.76–35.92 °C dla każdego wariantu
wejścia (sam kolor, sama szarość, obie wersje, plik połączony, film), a bez paska skali i z paletą
rainbow 35.60 °C. Na prawdziwych danych dokładność zależy przede wszystkim od tego, jak dokładnie
znany jest zakres temperatur obrazu. Obraz z zakresem 20 °C zapisany w 8 bitach ma rozdzielczość
ok. 0.08 °C na poziom jasności. Najlepsze wyniki dają dane radiometryczne (16 bit) z kamery.

Program nie jest wyrobem medycznym. Do pomiarów przesiewowych normy (IEC 80601-2-59) zalecają
pomiar w wewnętrznym kąciku oka i ciało czarne jako wzorzec odniesienia w kadrze.

## Test bez kamery

```bash
python make_synthetic.py przyklady   # tworzy syn_kolor/szary .png/.mp4 i syn_polaczony.png
python termo_analyzer.py --color przyklady/syn_kolor.png --gray przyklady/syn_szary.png --out wynik
```
