#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Odczyt danych radiometrycznych z plików kamer FLIR (np. T620 / T62101).

Kamera zapisuje zwykły JPG z paletą, ale w segmentach APP1 „FLIR” ukrywa plik FFF z:
  * surowym obrazem 16-bit z detektora (RawThermalImage, 640x480 dla T620),
  * stałymi kalibracji Plancka (R1, R2, B, F, O) danej kamery,
  * parametrami pomiaru ustawionymi w kamerze (emisyjność, odległość, temp. odbita,
    temp. i wilgotność powietrza, okno IR).
Z tego liczy się temperaturę każdego piksela dokładnie tak, jak robi to FLIR Tools
(wzór jak w ExifTool / pakiecie Thermimage). Nie trzeba wtedy znać skali kolorów.

Obsługiwane: radiometryczne JPG (zdjęcia), pliki .fff oraz nagrania .seq
(sekwencja ramek FFF z nieskompresowanym lub PNG obrazem). Nagrania .csq
(kompresja JPEG-LS) nie są jeszcze obsługiwane.
"""
from __future__ import annotations

import math
import struct
from dataclasses import dataclass, asdict
from typing import Iterator, Optional

import cv2
import numpy as np

REC_RAW = 1
REC_CAMERA_INFO = 32
REC_VISUAL = 14     # osadzone zdjęcie z kamery wizyjnej (JPEG)
REC_PIP = 42        # położenie obrazu termowizyjnego na zdjęciu wizyjnym


@dataclass
class FlirParams:
    emissivity: float
    object_distance: float          # m
    reflected_temp: float           # °C
    atmospheric_temp: float         # °C
    ir_window_temp: float           # °C
    ir_window_transmission: float
    relative_humidity: float        # 0..1
    planck_r1: float
    planck_r2: float
    planck_b: float
    planck_f: float
    planck_o: float
    ata1: float
    ata2: float
    atb1: float
    atb2: float
    atx: float
    range_min: float                # °C (zakres pomiarowy kamery)
    range_max: float
    camera_model: str = ""
    serial: str = ""
    raw_median: float = 0.0         # środek i szerokość skali wyświetlanej przez kamerę (surowe jednostki)
    raw_range: float = 0.0

    def as_dict(self):
        return asdict(self)


# ----------------------------------------------------------------------------
# Rozpakowanie kontenera
# ----------------------------------------------------------------------------

def extract_fff_from_jpeg(data: bytes) -> Optional[bytes]:
    """Skleja segmenty APP1 'FLIR\\0' z pliku JPEG w jeden blok FFF."""
    if data[:2] != b"\xff\xd8":
        return None
    pos, chunks = 2, {}
    n = len(data)
    while pos + 4 <= n:
        if data[pos] != 0xFF:
            pos += 1
            continue
        marker = data[pos + 1]
        if marker in (0xD8, 0x01) or 0xD0 <= marker <= 0xD7:
            pos += 2
            continue
        if marker == 0xDA:  # początek danych obrazu – dalej nie ma metadanych
            break
        length = struct.unpack(">H", data[pos + 2:pos + 4])[0]
        seg = data[pos + 4:pos + 2 + length]
        if marker == 0xE1 and seg[:5] == b"FLIR\x00" and len(seg) >= 8:
            chunks[seg[6]] = seg[8:]
        pos += 2 + length
    if not chunks:
        return None
    return b"".join(chunks[k] for k in sorted(chunks))


def _records(fff: bytes) -> dict[int, tuple[int, int]]:
    if fff[:4] != b"FFF\x00":
        raise ValueError("To nie jest blok FLIR FFF")
    ver = struct.unpack(">I", fff[20:24])[0]
    e = ">" if 100 <= ver < 200 else "<"
    dir_off, count = struct.unpack(e + "II", fff[24:32])
    recs = {}
    for i in range(count):
        o = dir_off + 32 * i
        rtype = struct.unpack(e + "H", fff[o:o + 2])[0]
        if rtype == 0:
            continue
        roff, rlen = struct.unpack(e + "II", fff[o + 12:o + 20])
        recs.setdefault(rtype, (roff, rlen))
    return recs


def _endian(rec: bytes) -> str:
    # pierwsze int16 rekordu = 2 w poprawnej kolejności bajtów (jak w ExifTool)
    return "<" if struct.unpack("<H", rec[:2])[0] == 2 else ">"


def parse_raw(rec: bytes) -> np.ndarray:
    e = _endian(rec)
    w, h = struct.unpack(e + "HH", rec[2:6])
    payload = rec[32:]
    if payload[:4] == b"\x89PNG":
        img = cv2.imdecode(np.frombuffer(payload, np.uint8), cv2.IMREAD_UNCHANGED)
        if img is None:
            raise ValueError("Nie udało się zdekodować surowego obrazu PNG")
        raw = img.astype(np.uint16).byteswap()  # FLIR zapisuje PNG z odwróconą kolejnością bajtów
    else:
        raw = np.frombuffer(payload[: w * h * 2], dtype=e + "u2").reshape(h, w)
    return raw.astype(np.float64)


def parse_camera_info(rec: bytes) -> FlirParams:
    e = _endian(rec)
    f = lambda o: struct.unpack(e + "f", rec[o:o + 4])[0]  # noqa: E731
    s = lambda o, n: rec[o:o + n].split(b"\x00")[0].decode("latin-1", "ignore").strip()  # noqa: E731
    k = 273.15
    rh = f(0x3C)
    if rh > 1.0:  # niektóre kamery zapisują w %
        rh /= 100.0
    return FlirParams(
        emissivity=f(0x20), object_distance=f(0x24), reflected_temp=f(0x28) - k,
        atmospheric_temp=f(0x2C) - k, ir_window_temp=f(0x30) - k, ir_window_transmission=f(0x34),
        relative_humidity=rh,
        planck_r1=f(0x58), planck_b=f(0x5C), planck_f=f(0x60),
        ata1=f(0x70), ata2=f(0x74), atb1=f(0x78), atb2=f(0x7C), atx=f(0x80),
        range_max=f(0x90) - k, range_min=f(0x94) - k,
        planck_o=float(struct.unpack(e + "i", rec[0x308:0x30C])[0]), planck_r2=f(0x30C),
        camera_model=s(0xD4, 32), serial=s(0x104, 16),
        raw_median=float(struct.unpack(e + "i", rec[0x338:0x33C])[0]) if len(rec) >= 0x340 else 0.0,
        raw_range=float(struct.unpack(e + "i", rec[0x33C:0x340])[0]) if len(rec) >= 0x340 else 0.0,
    )


def parse_fff(fff: bytes) -> tuple[np.ndarray, FlirParams]:
    recs = _records(fff)
    if REC_RAW not in recs or REC_CAMERA_INFO not in recs:
        raise ValueError("Brak surowych danych albo kalibracji w pliku FLIR")
    ro, rl = recs[REC_RAW]
    co, cl = recs[REC_CAMERA_INFO]
    return parse_raw(fff[ro:ro + rl]), parse_camera_info(fff[co:co + cl])


# ----------------------------------------------------------------------------
# Surowe wartości -> °C
# ----------------------------------------------------------------------------

def raw_to_celsius(raw: np.ndarray, p: FlirParams, emissivity: Optional[float] = None,
                   distance: Optional[float] = None, reflected: Optional[float] = None,
                   atmospheric: Optional[float] = None, humidity: Optional[float] = None) -> np.ndarray:
    """Wzór FLIR (jak FLIR Tools / ExifTool / Thermimage::raw2temp). Parametry None = z kamery."""
    E = p.emissivity if emissivity is None else emissivity
    OD = p.object_distance if distance is None else distance
    RT = p.reflected_temp if reflected is None else reflected
    AT = p.atmospheric_temp if atmospheric is None else atmospheric
    RH = p.relative_humidity if humidity is None else humidity
    IRT, IRWT = p.ir_window_transmission or 1.0, p.ir_window_temp
    R1, R2, B, F, O = p.planck_r1, p.planck_r2, p.planck_b, p.planck_f, p.planck_o
    E = min(max(E, 0.01), 1.0)

    h2o = RH * math.exp(1.5587 + 0.06939 * AT - 0.00027816 * AT ** 2 + 0.00000068455 * AT ** 3)
    d = math.sqrt(max(OD, 0.0) / 2)
    tau = p.atx * math.exp(-d * (p.ata1 + p.atb1 * math.sqrt(h2o))) + \
        (1 - p.atx) * math.exp(-d * (p.ata2 + p.atb2 * math.sqrt(h2o)))
    tau1 = tau2 = tau

    def planck_raw(tc):
        return R1 / (R2 * (math.exp(B / (tc + 273.15)) - F)) - O

    raw_refl = planck_raw(RT)
    raw_atm = planck_raw(AT)
    raw_wind = planck_raw(IRWT)
    emiss_wind = 1 - IRT
    refl_wind = 0.0
    raw_refl1_attn = (1 - E) / E * raw_refl
    raw_atm1_attn = (1 - tau1) / E / tau1 * raw_atm
    raw_wind_attn = emiss_wind / E / tau1 / IRT * raw_wind
    raw_refl2_attn = refl_wind / E / tau1 / IRT * raw_refl
    raw_atm2_attn = (1 - tau2) / E / tau1 / IRT / tau2 * raw_atm
    raw_obj = raw / E / tau1 / IRT / tau2 - raw_atm1_attn - raw_atm2_attn - raw_wind_attn \
        - raw_refl1_attn - raw_refl2_attn
    with np.errstate(invalid="ignore", divide="ignore"):
        t = B / np.log(R1 / (R2 * (raw_obj + O)) + F) - 273.15
    return np.nan_to_num(t, nan=-273.15).astype(np.float32)


# ----------------------------------------------------------------------------
# API dla analizatora
# ----------------------------------------------------------------------------

def display_scale(p: FlirParams) -> Optional[tuple[float, float]]:
    """Zakres skali, który kamera pokazała na zdjęciu (min, max) w °C."""
    if p.raw_range <= 0 or p.raw_median <= 0:
        return None
    t = raw_to_celsius(np.array([p.raw_median - p.raw_range / 2, p.raw_median + p.raw_range / 2]), p)
    return float(t[0]), float(t[1])


def read_flir_file(path: str) -> Optional[tuple[np.ndarray, FlirParams]]:
    """Zwraca (surowe wartości, parametry) dla radiometrycznego JPG/FFF albo None."""
    with open(path, "rb") as fh:
        data = fh.read()
    fff = data if data[:4] == b"FFF\x00" else extract_fff_from_jpeg(data)
    if fff is None:
        return None
    try:
        return parse_fff(fff)
    except (ValueError, struct.error, IndexError):
        return None


def iter_seq(path: str, step: int = 1) -> Iterator[tuple[np.ndarray, FlirParams]]:
    """Kolejne ramki nagrania .seq (każda ramka to osobny blok FFF)."""
    with open(path, "rb") as fh:
        data = fh.read()
    starts = []
    i = data.find(b"FFF\x00")
    while i >= 0:
        starts.append(i)
        i = data.find(b"FFF\x00", i + 4)
    starts.append(len(data))
    for n in range(0, len(starts) - 1, step):
        try:
            yield parse_fff(data[starts[n]:starts[n + 1]])
        except (ValueError, struct.error, IndexError):
            continue


def parse_pip(rec: bytes) -> Optional[dict]:
    """Rekord PiP: Real2IR (ile razy pole widzenia zdjęcia wizyjnego jest szersze) i przesunięcie
    środka obrazu termowizyjnego względem środka zdjęcia wizyjnego (piksele zdjęcia)."""
    if len(rec) < 8:
        return None
    for e in "<>":
        r2ir = struct.unpack(e + "f", rec[0:4])[0]
        if 0.3 < r2ir < 20:
            ox, oy = struct.unpack(e + "hh", rec[4:8])
            return {"real2ir": float(r2ir), "offset_x": int(ox), "offset_y": int(oy)}
    return None


def read_flir_visual(path: str) -> tuple[Optional[np.ndarray], Optional[dict]]:
    """Zwraca (osadzone zdjęcie wizyjne BGR, parametry PiP) z radiometrycznego JPG FLIR."""
    try:
        with open(path, "rb") as fh:
            data = fh.read()
        fff = data if data[:4] == b"FFF\x00" else extract_fff_from_jpeg(data)
        if fff is None:
            return None, None
        recs = _records(fff)
        vis = pip = None
        if REC_VISUAL in recs:
            o, n = recs[REC_VISUAL]
            rec = fff[o:o + n]
            j = rec.find(b"\xff\xd8")
            if j >= 0:
                vis = cv2.imdecode(np.frombuffer(rec[j:], np.uint8), cv2.IMREAD_COLOR)
        if REC_PIP in recs:
            o, n = recs[REC_PIP]
            pip = parse_pip(fff[o:o + n])
        return vis, pip
    except (ValueError, struct.error, IndexError, cv2.error):
        return None, None


def is_flir_radiometric(path: str) -> bool:
    low = path.lower()
    if low.endswith((".seq", ".fff")):
        return True
    if low.endswith((".jpg", ".jpeg")):
        with open(path, "rb") as fh:
            head = fh.read(256 * 1024)
        return b"FLIR\x00" in head and b"FFF\x00" in head
    return False


if __name__ == "__main__":
    import sys
    raw, prm = read_flir_file(sys.argv[1])
    t = raw_to_celsius(raw, prm)
    print(prm)
    print(f"raw {raw.shape} min {raw.min():.0f} max {raw.max():.0f}")
    print(f"T min {t.min():.2f}  mediana {np.median(t):.2f}  max {t.max():.2f} °C")
