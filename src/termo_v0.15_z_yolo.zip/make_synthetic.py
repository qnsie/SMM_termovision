#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generator syntetycznych danych testowych: sylwetka człowieka o znanej temperaturze,
renderowana w palecie 'iron' z paskiem skali (wersja kolorowa) i w skali szarości.
Służy tylko do sprawdzenia, czy program działa, zanim dostaniemy prawdziwe pliki."""
import os
import sys

import cv2
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from termo_analyzer import builtin_palettes  # noqa: E402

TMIN, TMAX = 20.0, 40.0
FOREHEAD_T = 35.8
BODY_T = 32.0


def scene(w=640, h=480, dx=0, seed=0):
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    t = 22.0 + 1.5 * yy / h  # tło z lekkim gradientem
    cx = w * 0.45 + dx
    def ell(cx_, cy, rx, ry):
        return ((xx - cx_) / rx) ** 2 + ((yy - cy) / ry) ** 2 <= 1
    torso = ell(cx, h * 0.98, w * 0.24, h * 0.36)
    neck = (np.abs(xx - cx) < w * 0.045) & (yy > h * 0.48) & (yy < h * 0.66)
    head = ell(cx, h * 0.37, w * 0.085, h * 0.15)
    t[torso] = BODY_T
    t[neck] = 33.5
    t[head] = 34.6
    hair = head & (yy < h * 0.37 - h * 0.15 * 0.72)
    t[hair] = 27.5
    forehead = ell(cx, h * 0.30, w * 0.06, h * 0.035) & ~hair
    t[forehead] = FOREHEAD_T
    for ex in (-1, 1):  # kąciki oczu – najcieplejsze miejsca
        t[ell(cx + ex * w * 0.035, h * 0.355, w * 0.012, h * 0.008)] = 36.3
    t[ell(cx, h * 0.43, w * 0.03, h * 0.012)] = 34.0  # usta
    t = cv2.GaussianBlur(t, (0, 0), 1.5)
    t += rng.normal(0, 0.12, t.shape).astype(np.float32)
    return t


def render(t, bar=True):
    pal = builtin_palettes()["iron"]
    v = np.clip((t - TMIN) / (TMAX - TMIN), 0, 1)
    idx = (v * 255).round().astype(np.int32)
    color = pal[idx][..., ::-1].copy()  # BGR
    gray = (v * 255).round().astype(np.uint8)
    if bar:
        h, w = t.shape
        x0, x1, y0, y1 = w - 40, w - 22, 40, h - 40
        ramp = np.linspace(255, 0, y1 - y0).round().astype(np.int32)
        color[y0:y1, x0:x1] = pal[ramp][:, None, ::-1]
        gray[y0:y1, x0:x1] = ramp[:, None].astype(np.uint8)
        for img in (color, gray):
            cv2.putText(img, f"{TMAX:.0f}", (w - 58, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            cv2.putText(img, f"{TMIN:.0f}", (w - 58, h - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            cv2.putText(img, "Sp1 35.8C", (10, h - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    return color, gray


def main(out="przyklady"):
    os.makedirs(out, exist_ok=True)
    t = scene()
    c, g = render(t)
    cv2.imwrite(os.path.join(out, "syn_kolor.png"), c)
    cv2.imwrite(os.path.join(out, "syn_szary.png"), g)
    cv2.imwrite(os.path.join(out, "syn_polaczony.png"), np.hstack([c, cv2.cvtColor(g, cv2.COLOR_GRAY2BGR)]))
    vc = cv2.VideoWriter(os.path.join(out, "syn_kolor.mp4"), cv2.VideoWriter_fourcc(*"mp4v"), 10, (640, 480))
    vg = cv2.VideoWriter(os.path.join(out, "syn_szary.mp4"), cv2.VideoWriter_fourcc(*"mp4v"), 10, (640, 480))
    for i in range(30):
        c, g = render(scene(dx=int(60 * np.sin(i / 5)), seed=i))
        vc.write(c)
        vg.write(cv2.cvtColor(g, cv2.COLOR_GRAY2BGR))
    vc.release(); vg.release()
    print(f"Zapisano w {out}. Prawdziwe wartości: czoło {FOREHEAD_T} °C, tułów {BODY_T} °C, skala {TMIN}-{TMAX} °C")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "przyklady")
