"""Porównanie wykrywania twarzy: YOLO jak w 0.7 (--yolo-prosty) i nowe warianty termowizyjne.
Użycie: python ocena_twarzy.py FILM1.mp4 [FILM2.mp4 ...] [--step 2]
Wynik: tabela w konsoli + diag/twarze_<film>.png (12 klatek z ramkami twarzy)."""
import collections
import io
import json
import os
import sys
import time
import contextlib

import cv2
import numpy as np

import termo_analyzer as ta


def run(path, extra, out, step):
    t0 = time.time()
    with contextlib.redirect_stdout(io.StringIO()):
        ta.main(["--color", path, "--out", out, "--step", str(step)] + extra)
    rep = json.load(open(os.path.join(out, "raport.json"), encoding="utf-8"))
    return rep["klatki"], time.time() - t0


def sheet(path, frames, step, out_png):
    cap = cv2.VideoCapture(path)
    idx = np.linspace(0, len(frames) - 1, 12).astype(int)
    tiles = []
    for i in idx:
        fr = frames[i]
        cap.set(cv2.CAP_PROP_POS_FRAMES, fr["frame"])
        ok, img = cap.read()
        if not ok:
            continue
        if fr.get("twarz"):
            x, y, w, h = fr["twarz"]
            cv2.rectangle(img, (x, y), (x + w, y + h), (255, 255, 0), 1)
        cv2.putText(img, f"{fr['frame']} {fr.get('metoda_twarzy') or 'brak'}", (4, img.shape[0] - 6),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1, cv2.LINE_AA)
        tiles.append(img)
    while len(tiles) % 4:
        tiles.append(np.zeros_like(tiles[0]))
    rows = [np.hstack(tiles[k:k + 4]) for k in range(0, len(tiles), 4)]
    cv2.imwrite(out_png, np.vstack(rows))


def main():
    args = sys.argv[1:]
    step = 2
    if "--step" in args:
        k = args.index("--step"); step = int(args[k + 1]); del args[k:k + 2]
    os.makedirs("diag", exist_ok=True)
    for path in args:
        name = os.path.splitext(os.path.basename(path))[0]
        print(f"\n=== {name}")
        for label, extra in (("0.7 (prosty)", ["--yolo-prosty"]), ("nowy", [])):
            out = os.path.join("diag", f"ocena_{name}_{'prosty' if extra else 'nowy'}")
            frames, dt = run(path, extra, out, step)
            cnt = collections.Counter(f.get("metoda_twarzy") or "brak twarzy" for f in frames)
            yolo = sum(v for k, v in cnt.items() if k.startswith("yolo"))
            fo = [f["twarz_max"] for f in frames if f.get("twarz_max") is not None]
            jumps = 0
            prev = None
            for f in frames:
                b = f.get("twarz")
                if b and prev:
                    cx, cy = b[0] + b[2] / 2, b[1] + b[3] / 2
                    px, py = prev[0] + prev[2] / 2, prev[1] + prev[3] / 2
                    if abs(cx - px) > 0.5 * prev[2] or abs(cy - py) > 0.5 * prev[3]:
                        jumps += 1
                prev = b or prev
            print(f"  {label:13s} klatek {len(frames):4d} | YOLO {100 * yolo / len(frames):5.1f}% | "
                  + ", ".join(f"{k} {v}" for k, v in cnt.most_common())
                  + f" | skoki ramki {jumps} | najciepl. punkt sr {np.mean(fo) if fo else float('nan'):.2f} "
                  f"odch {np.std(fo) if fo else float('nan'):.2f} | {dt:.0f} s")
            if not extra:
                sheet(path, frames, step, os.path.join("diag", f"twarze_{name}.png"))


if __name__ == "__main__":
    main()
