@echo off
REM Buduje AnalizatorTermo.exe (Windows). Wymaga Pythona 3.9+ (python.org lub "py").
REM Jesli obok lezy yolov8n-face.onnx, model zostanie wbudowany w exe.
cd /d "%~dp0"
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
if not exist .venv\Scripts\python.exe (
  %PY% -m venv .venv || goto :err
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install "numpy>=1.24" "opencv-python-headless>=4.8,<5" "onnxruntime>=1.16" "pillow>=9" "customtkinter>=5.2" pyinstaller || goto :err
set EXTRA=
if exist yolov8n-face.onnx set EXTRA=--add-data "yolov8n-face.onnx;."
pyinstaller --noconfirm --onefile --windowed --name AnalizatorTermo ^
  --collect-data cv2 --collect-data customtkinter --collect-binaries onnxruntime --hidden-import termo_analyzer --hidden-import flir_radiometric ^
  --hidden-import scale_ocr --hidden-import PIL.ImageFont --hidden-import PIL.ImageTk %EXTRA% termo_gui.py || goto :err
echo.
echo Gotowe: %~dp0dist\AnalizatorTermo.exe
goto :eof
:err
echo BLAD budowania - sprawdz komunikaty powyzej.
exit /b 1
