#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Odczyt liczb przy pasku skali (temperatura maksymalna i minimalna) z obrazu termowizyjnego.

Bez zewnętrznego OCR: cyfry są wycinane jako spójne kształty i porównywane z wzorcami
wyrenderowanymi z czcionek systemowych (Arial/Segoe/Tahoma na Windows, DejaVu/Liberation
na Linuksie; zapasowo czcionki OpenCV). Wynik jest sprawdzany (min < max, rozsądny zakres).
"""
from __future__ import annotations

import os
import re
from typing import Optional

import cv2
import numpy as np

CHARS = "0123456789CF"
N = 24  # rozmiar znormalizowanego znaku

_FONT_CANDIDATES = [
    r"C:\Windows\Fonts\arial.ttf", r"C:\Windows\Fonts\segoeui.ttf", r"C:\Windows\Fonts\tahoma.ttf",
    r"C:\Windows\Fonts\verdana.ttf", r"C:\Windows\Fonts\calibri.ttf", r"C:\Windows\Fonts\consola.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    "/usr/share/fonts/truetype/freefont/FreeSans.ttf", "/usr/share/fonts/opentype/inter/Inter-Regular.otf",
    "/Library/Fonts/Arial.ttf", "/System/Library/Fonts/Helvetica.ttc",
]

_templates = None


def _holes(mask: np.ndarray) -> int:
    m = np.pad(mask.astype(np.uint8), 1)
    n, _ = cv2.connectedComponents((1 - m).astype(np.uint8), connectivity=4)
    return n - 2  # bez tła zewnętrznego (etykieta 0 = kształt, 1 = tło)


def _normalize(mask: np.ndarray) -> Optional[np.ndarray]:
    ys, xs = np.nonzero(mask)
    if len(ys) == 0:
        return None
    g = mask[ys.min():ys.max() + 1, xs.min():xs.max() + 1].astype(np.uint8) * 255
    h, w = g.shape
    s = (N - 2) / h
    nw = max(1, min(N - 2, int(round(w * s))))
    g = cv2.resize(g, (nw, N - 2), interpolation=cv2.INTER_AREA)
    out = np.zeros((N, N), np.uint8)
    x0 = (N - nw) // 2
    out[1:N - 1, x0:x0 + nw] = g
    return out > 80


def _render_pil(font_path: str, ch: str, size: int):
    from PIL import Image, ImageDraw, ImageFont  # noqa
    f = ImageFont.truetype(font_path, size)
    img = Image.new("L", (size * 2, size * 2), 0)
    ImageDraw.Draw(img).text((size // 3, size // 4), ch, fill=255, font=f)
    return np.array(img) > 100


def _templates_list():
    global _templates
    if _templates is not None:
        return _templates
    t = []
    try:
        import PIL  # noqa: F401
        for fp in _FONT_CANDIDATES:
            if os.path.exists(fp):
                for size in (14, 22, 40):
                    for ch in CHARS:
                        try:
                            m = _normalize(_render_pil(fp, ch, size))
                        except Exception:
                            m = None
                        if m is not None:
                            t.append((ch, m, _holes(m)))
    except ImportError:
        pass
    for font in (cv2.FONT_HERSHEY_SIMPLEX, cv2.FONT_HERSHEY_DUPLEX, cv2.FONT_HERSHEY_PLAIN):
        for th in (1, 2):
            for ch in CHARS:
                img = np.zeros((80, 80), np.uint8)
                cv2.putText(img, ch, (10, 60), font, 1.6, 255, th, cv2.LINE_AA)
                m = _normalize(img > 100)
                if m is not None:
                    t.append((ch, m, _holes(m)))
    _templates = t
    return t


def _chamfer(a: np.ndarray, b: np.ndarray) -> float:
    da = cv2.distanceTransform((~a).astype(np.uint8), cv2.DIST_L2, 3)
    db = cv2.distanceTransform((~b).astype(np.uint8), cv2.DIST_L2, 3)
    return float(da[b].mean() + db[a].mean()) / 2 if a.any() and b.any() else 99.0


def classify(mask: np.ndarray) -> tuple[str, float]:
    m = _normalize(mask)
    if m is None:
        return "?", 99.0
    # grube/cienkie kreski: wyrównujemy szkieletem przez lekkie pogrubienie obu stron
    hm = _holes(mask)
    m = cv2.dilate(m.astype(np.uint8), np.ones((2, 2), np.uint8)) > 0
    best = ("?", 99.0)
    for ch, t, th in _templates_list():
        tt = cv2.dilate(t.astype(np.uint8), np.ones((2, 2), np.uint8)) > 0
        d = _chamfer(m, tt) + (0.6 if th != hm else 0.0)  # liczba „dziurek” (0, 6, 8, 9...) musi się zgadzać
        if d < best[1]:
            best = (ch, d)
    return best


def read_number(region_bgr: np.ndarray, anchor: str = "nearest") -> Optional[tuple[float, str, tuple]]:
    """Czyta liczbę (np. 32.6, -5, 120) z fragmentu obrazu. Zwraca (wartość, tekst, bbox linii)."""
    if region_bgr.size == 0:
        return None
    reg = cv2.resize(region_bgr, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    hsv = cv2.cvtColor(reg, cv2.COLOR_BGR2HSV)
    gray = hsv[..., 2]
    lines = []
    # biały lub czarny tekst; dodatkowo niższy próg dla cienkich, rozmytych cyfr (np. po kompresji filmu)
    for mask in ((gray > 150) & (hsv[..., 1] < 90), (gray > 105) & (hsv[..., 1] < 90), (gray < 70) & (hsv[..., 1] < 90)):
        n, lab, st, _ = cv2.connectedComponentsWithStats(mask.astype(np.uint8), 8)
        comps = [(st[i], i) for i in range(1, n)]
        if not comps:
            continue
        # znaki cyfr: wysokość 7..60 px (po powiększeniu 3x: 21..180)
        digits = [(s, i) for s, i in comps if 18 <= s[cv2.CC_STAT_HEIGHT] <= 200 and s[cv2.CC_STAT_WIDTH] <= s[cv2.CC_STAT_HEIGHT] * 1.2]
        # grupowanie w linie po osi y
        digits.sort(key=lambda d: d[0][cv2.CC_STAT_TOP])
        groups = []
        for d in digits:
            s = d[0]
            cy = s[cv2.CC_STAT_TOP] + s[cv2.CC_STAT_HEIGHT] / 2
            for g in groups:
                if abs(g["cy"] - cy) < 0.4 * g["h"] and abs(g["h"] - s[cv2.CC_STAT_HEIGHT]) < 0.35 * g["h"]:
                    g["items"].append(d)
                    break
            else:
                groups.append({"cy": cy, "h": s[cv2.CC_STAT_HEIGHT], "items": [d]})
        for g in groups:
            items = sorted(g["items"], key=lambda d: d[0][cv2.CC_STAT_LEFT])
            # znaki muszą stać blisko siebie
            chunks, cur = [], [items[0]]
            for d in items[1:]:
                prev = cur[-1][0]
                gap = d[0][cv2.CC_STAT_LEFT] - (prev[cv2.CC_STAT_LEFT] + prev[cv2.CC_STAT_WIDTH])
                (cur.append(d) if gap < 0.9 * g["h"] else (chunks.append(cur), cur := [d]))
            chunks.append(cur)
            for ch in chunks:
                text, score = "", 0.0
                x0 = ch[0][0][cv2.CC_STAT_LEFT]
                x1 = ch[-1][0][cv2.CC_STAT_LEFT] + ch[-1][0][cv2.CC_STAT_WIDTH]
                top = min(d[0][cv2.CC_STAT_TOP] for d in ch)
                bot = max(d[0][cv2.CC_STAT_TOP] + d[0][cv2.CC_STAT_HEIGHT] for d in ch)
                hgt = bot - top
                # kropki i minusy (małe kształty w obrębie linii)
                extras = []
                for s, i in comps:
                    if s[cv2.CC_STAT_HEIGHT] < 0.35 * hgt and x0 - hgt <= s[cv2.CC_STAT_LEFT] <= x1:
                        cy = s[cv2.CC_STAT_TOP] + s[cv2.CC_STAT_HEIGHT] / 2
                        sw, sh = s[cv2.CC_STAT_WIDTH], s[cv2.CC_STAT_HEIGHT]
                        if top + 0.3 * hgt <= cy <= top + 0.75 * hgt and sw > 1.8 * sh and s[cv2.CC_STAT_LEFT] < x0:
                            extras.append((s[cv2.CC_STAT_LEFT], "-"))
                        elif bot - 0.3 * hgt <= cy <= bot + 0.1 * hgt and sw < 0.45 * hgt and sw <= 1.8 * sh:
                            extras.append((s[cv2.CC_STAT_LEFT], "."))
                toks = []
                for s, i in ch:
                    c, d = classify(lab[s[cv2.CC_STAT_TOP]:s[cv2.CC_STAT_TOP] + s[cv2.CC_STAT_HEIGHT],
                                        s[cv2.CC_STAT_LEFT]:s[cv2.CC_STAT_LEFT] + s[cv2.CC_STAT_WIDTH]] == i)
                    toks.append((s[cv2.CC_STAT_LEFT], c))
                    score += d
                toks += extras
                text = "".join(c for _, c in sorted(toks))
                mm = re.search(r"-?\d+(\.\d+)?", text)
                if mm:
                    bbox = (x0 / 3, top / 3, (x1 - x0) / 3, hgt / 3)
                    lines.append((float(mm.group(0)), mm.group(0), bbox, score / max(1, len(ch))))
    if not lines:
        return None
    return lines


def read_scale(bgr: np.ndarray, bar) -> Optional[tuple[float, float, str]]:
    """Odczytuje (tmin, tmax, opis) z liczb przy końcach paska skali."""
    H, W = bgr.shape[:2]
    if bar.orientation == "vertical":
        bw = bar.x1 - bar.x0
        xa, xb = max(0, bar.x0 - max(40, int(0.15 * W))), min(W, bar.x1 + max(40, int(0.15 * W)))
        hot_reg = (xa, max(0, bar.y0 - int(0.15 * H)), xb, bar.y0 + 2)
        cold_reg = (xa, bar.y1 - 2, xb, min(H, bar.y1 + int(0.15 * H)))
        hot_anchor, cold_anchor = (bar.x0 + bw / 2, bar.y0), (bar.x0 + bw / 2, bar.y1)
    else:
        bh = bar.y1 - bar.y0
        ya, yb = max(0, bar.y0 - max(30, int(0.12 * H))), min(H, bar.y1 + max(30, int(0.12 * H)))
        cold_reg = (max(0, bar.x0 - int(0.2 * W)), ya, bar.x0 + 2, yb)
        hot_reg = (bar.x1 - 2, ya, min(W, bar.x1 + int(0.2 * W)), yb)
        cold_anchor, hot_anchor = (bar.x0, bar.y0 + bh / 2), (bar.x1, bar.y0 + bh / 2)

    def pick(reg, anchor):
        x0, y0, x1, y1 = reg
        res = read_number(bgr[y0:y1, x0:x1])
        if not res:
            return None
        def dist(r):
            bx, by, bw_, bh_ = r[2]
            cx, cy = x0 + bx + bw_ / 2, y0 + by + bh_ / 2
            return np.hypot(cx - anchor[0], cy - anchor[1])
        return min(res, key=lambda r: (r[3] >= 0.5, -len(r[1].replace(".", "").replace("-", "")), dist(r)))

    hi, lo = pick(hot_reg, hot_anchor), pick(cold_reg, cold_anchor)
    if hi is None or lo is None:
        return None
    tmax, tmin = hi[0], lo[0]
    if not (-60 <= tmin < tmax <= 2500):
        return None
    return tmin, tmax, f"odczytano z obrazu: max '{hi[1]}', min '{lo[1]}'"
