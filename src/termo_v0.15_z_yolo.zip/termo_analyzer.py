#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Analizator temperatury człowieka z kamery termowizyjnej.

Wejście: zdjęcie albo film w DWÓCH wersjach jednocześnie:
  * kolorowej (paleta odwzorowująca temperaturę, np. "iron"/"rainbow", często z paskiem skali),
  * czarno-białej (skala szarości proporcjonalna do temperatury).
Można też podać jeden plik, w którym obie wersje leżą obok siebie (--split).

Wyjście:
  * średnia temperatura powierzchni ciała,
  * wykryta twarz i jej najcieplejszy punkt (np. wewnętrzny kącik oka),
  * obraz/film z adnotacjami + raport JSON (+ CSV klatek dla filmu).

ZAŁOŻENIA (do potwierdzenia, gdy poznamy model kamery i przykładowe pliki):
  Z1. Zakres temperatur obrazu jest liniowy: najciemniejszy/„najzimniejszy” kolor = --tmin,
      najjaśniejszy/„najgorętszy” = --tmax (domyślnie 20..40 °C). Typowe kamery pokazują
      te liczby przy pasku skali; trzeba je wpisać (OCR nie jest jeszcze zaimplementowany).
  Z2. Pasek skali (jeśli jest) to pionowy lub poziomy pas przy krawędzi obrazu; gorąco
      jest na górze (pionowy) lub po prawej (poziomy). Jeśli paska brak, paleta jest
      dobierana z wbudowanych (iron, rainbow/jet, inferno, hot, gray).
  Z3. Obraz szary: biały = gorąco ("white-hot"). Jeśli korelacja z obrazem kolorowym jest
      ujemna, obraz jest automatycznie odwracany ("black-hot").
      Obraz 16-bitowy (TIFF/PNG) można traktować jako radiometryczny: T = gain*v + offset
      (np. FLIR centykelwiny: --gray-gain 0.01 --gray-offset -273.15).
  Z4. Obie wersje przedstawiają tę samą scenę w tym samym kadrze (ewentualnie inną
      rozdzielczość – wtedy są skalowane do wspólnego rozmiaru).
  Z5. Kamera mierzy temperaturę POWIERZCHNI skóry. Temperatura wewnętrzna jest zwykle
      wyższa o ok. 0.5–1.5 °C – można dodać stałą korekcję --core-offset (domyślnie 0).
"""
from __future__ import annotations

import argparse
import itertools
import csv
import json
import os
import sys
from dataclasses import dataclass, field, asdict
from typing import Iterator, Optional

import cv2
import numpy as np

import flir_radiometric as flir
import scale_ocr

IMAGE_EXT = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}
VIDEO_EXT = {".mp4", ".avi", ".mov", ".mkv", ".wmv", ".m4v", ".mpg", ".mpeg", ".webm"}


# ----------------------------------------------------------------------------
# Palety
# ----------------------------------------------------------------------------

def _interp_palette(stops: list[tuple[float, tuple[int, int, int]]], n: int = 256) -> np.ndarray:
    """Buduje paletę n kolorów (RGB, od zimnego do gorącego) z punktów kontrolnych."""
    xs = np.array([s[0] for s in stops], dtype=np.float32)
    cols = np.array([s[1] for s in stops], dtype=np.float32)
    t = np.linspace(0, 1, n, dtype=np.float32)
    out = np.stack([np.interp(t, xs, cols[:, c]) for c in range(3)], axis=1)
    return np.clip(out, 0, 255).astype(np.uint8)


def _cv_colormap(cmap: int) -> np.ndarray:
    ramp = np.arange(256, dtype=np.uint8).reshape(-1, 1)
    bgr = cv2.applyColorMap(ramp, cmap).reshape(-1, 3)
    return bgr[:, ::-1].copy()  # -> RGB


def builtin_palettes() -> dict[str, np.ndarray]:
    """Wbudowane palety jako tablice RGB (256x3), indeks 0 = najzimniej."""
    pals = {
        # Paleta „iron/ironbow” (FLIR, Testo, Hikmicro – przybliżenie)
        "iron": _interp_palette([
            (0.00, (0, 0, 0)), (0.10, (32, 0, 96)), (0.25, (112, 0, 150)),
            (0.40, (180, 20, 130)), (0.55, (225, 70, 40)), (0.70, (245, 130, 0)),
            (0.85, (255, 200, 20)), (1.00, (255, 255, 240))]),
        "rainbow": _interp_palette([
            (0.00, (0, 0, 128)), (0.15, (0, 0, 255)), (0.35, (0, 200, 255)),
            (0.50, (0, 255, 0)), (0.65, (255, 255, 0)), (0.85, (255, 64, 0)),
            (1.00, (255, 255, 255))]),
        "jet": _cv_colormap(cv2.COLORMAP_JET),
        "inferno": _cv_colormap(cv2.COLORMAP_INFERNO),
        "hot": _cv_colormap(cv2.COLORMAP_HOT),
        "turbo": _cv_colormap(cv2.COLORMAP_TURBO),
        "gray": np.repeat(np.arange(256, dtype=np.uint8)[:, None], 3, axis=1),
    }
    return pals


class PaletteMapper:
    """Zamienia kolor (BGR) na wartość znormalizowaną 0..1 przez najbliższy kolor palety w Lab.

    Dla szybkości budowana jest tablica 3D 32x32x32 (kwantyzacja co 8 poziomów).
    """

    Q = 8  # krok kwantyzacji

    def __init__(self, palette_rgb: np.ndarray, name: str = "custom"):
        self.name = name
        self.palette_rgb = palette_rgb.astype(np.uint8)
        n = len(palette_rgb)
        pal_lab = cv2.cvtColor(self.palette_rgb[None, :, ::-1], cv2.COLOR_BGR2LAB)[0].astype(np.float32)
        g = (np.arange(0, 256, self.Q) + self.Q // 2).clip(0, 255).astype(np.uint8)
        bb, gg, rr = np.meshgrid(g, g, g, indexing="ij")
        grid_bgr = np.stack([bb, gg, rr], axis=-1).reshape(1, -1, 3)
        grid_lab = cv2.cvtColor(grid_bgr, cv2.COLOR_BGR2LAB)[0].astype(np.float32)
        idx = np.empty(len(grid_lab), dtype=np.int32)
        err = np.empty(len(grid_lab), dtype=np.float32)
        step = 4096
        for s in range(0, len(grid_lab), step):
            d = ((grid_lab[s:s + step, None, :] - pal_lab[None, :, :]) ** 2).sum(-1)
            idx[s:s + step] = d.argmin(1)
            err[s:s + step] = np.sqrt(d.min(1))
        k = 256 // self.Q
        self.lut_val = (idx / max(n - 1, 1)).astype(np.float32).reshape(k, k, k)
        self.lut_err = err.reshape(k, k, k)

        self.pal_lab = pal_lab
        self._ck = np.empty(0, np.int64)   # pamięć podręczna dokładnych wyników dla kolorów już widzianych
        self._cv = np.empty(0, np.float32)
        self._ce = np.empty(0, np.float32)

    def map_fast(self, bgr: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Szybka wersja przybliżona (siatka 32x32x32) – do wyboru palety i dopasowania obrazów."""
        q = (bgr // self.Q).astype(np.intp)
        b, g, r = q[..., 0], q[..., 1], q[..., 2]
        return self.lut_val[b, g, r], self.lut_err[b, g, r]

    def _exact(self, cols_bgr: np.ndarray):
        """Dokładne dopasowanie kolorów: najbliższy kolor palety, a potem interpolacja między nim
        a sąsiednim kolorem palety (rzut na odcinek w Lab). Daje ciągłą wartość zamiast schodków."""
        lab = cv2.cvtColor(cols_bgr.reshape(1, -1, 3).astype(np.uint8), cv2.COLOR_BGR2LAB)[0].astype(np.float32)
        P = self.pal_lab
        n = len(P)
        val = np.empty(len(lab), np.float32)
        err = np.empty(len(lab), np.float32)
        for s in range(0, len(lab), 4096):
            L = lab[s:s + 4096]
            d = ((L[:, None, :] - P[None, :, :]) ** 2).sum(-1)
            i = d.argmin(1)
            best_v = i.astype(np.float32)
            best_e = d[np.arange(len(i)), i]
            for nb in (-1, 1):
                j = np.clip(i + nb, 0, n - 1)
                a, b = P[i], P[j]
                ab = b - a
                den = (ab ** 2).sum(-1)
                tt = np.where(den > 0, ((L - a) * ab).sum(-1) / np.maximum(den, 1e-9), 0.0).clip(0, 1)
                e = ((L - (a + tt[:, None] * ab)) ** 2).sum(-1)
                better = (e < best_e) & (j != i)
                best_e = np.where(better, e, best_e)
                best_v = np.where(better, i + tt * (j - i), best_v)
            val[s:s + 4096] = best_v / max(n - 1, 1)
            err[s:s + 4096] = np.sqrt(best_e)
        return val, err

    def map(self, bgr: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Zwraca (wartość 0..1, błąd dopasowania w jednostkach Lab) dla każdego piksela (dokładnie)."""
        b8 = bgr.astype(np.int64)
        key = (b8[..., 0] << 16) | (b8[..., 1] << 8) | b8[..., 2]
        uk, inv = np.unique(key.ravel(), return_inverse=True)
        pos = np.searchsorted(self._ck, uk)
        pos_c = np.minimum(pos, max(0, len(self._ck) - 1))
        known = (len(self._ck) > 0) & (self._ck[pos_c] == uk) if len(self._ck) else np.zeros(len(uk), bool)
        v = np.empty(len(uk), np.float32)
        e = np.empty(len(uk), np.float32)
        if known.any():
            v[known], e[known] = self._cv[pos_c[known]], self._ce[pos_c[known]]
        new = ~known
        if new.any():
            nk = uk[new]
            cols = np.stack([(nk >> 16) & 255, (nk >> 8) & 255, nk & 255], -1)
            v[new], e[new] = self._exact(cols)
            if len(self._ck) < 2_000_000:  # pamięć podręczna dla kolejnych klatek filmu
                allk = np.concatenate([self._ck, nk])
                o = np.argsort(allk)
                self._ck = allk[o]
                self._cv = np.concatenate([self._cv, v[new]])[o]
                self._ce = np.concatenate([self._ce, e[new]])[o]
        sh = bgr.shape[:2]
        return v[inv].reshape(sh), e[inv].reshape(sh)


# ----------------------------------------------------------------------------
# Wykrywanie paska skali
# ----------------------------------------------------------------------------

@dataclass
class ColorBar:
    x0: int
    y0: int
    x1: int
    y1: int
    orientation: str  # "vertical" | "horizontal"
    palette_rgb: np.ndarray = field(repr=False)


def detect_colorbar(bgr: np.ndarray, hot_end: str = "auto") -> Optional[ColorBar]:
    """Szuka paska skali: pas przy krawędzi, w którym sąsiednie kolumny (wiersze) są niemal
    identyczne, a kolor zmienia się płynnie wzdłuż paska w szerokim zakresie."""
    h, w = bgr.shape[:2]
    img = bgr.astype(np.int16)
    best = None

    def scan(arr: np.ndarray, length: int, side_cols: range, orient: str):
        nonlocal best
        # arr: obraz w orientacji, gdzie pasek jest pionowy (kolumny wzdłuż osi 1)
        H = arr.shape[0]
        diffs = np.abs(np.diff(arr, axis=1)).sum(-1)  # H x (W-1)
        prev_ok = None
        run = []
        for x in side_cols:
            if x >= arr.shape[1] - 1:
                continue
            col = arr[:, x]
            similar = diffs[:, x] < 30
            # najdłuższy ciągły fragment, w którym kolumna x ~ kolumna x+1
            best_len, best_s, cur, s = 0, 0, 0, 0
            for i, ok in enumerate(similar):
                if ok:
                    if cur == 0:
                        s = i
                    cur += 1
                    if cur > best_len:
                        best_len, best_s = cur, s
                else:
                    cur = 0
            if best_len < 0.4 * H:
                run = []
                continue
            seg = col[best_s:best_s + best_len]
            span = np.ptp(seg.astype(np.float32), axis=0).sum()
            step = np.abs(np.diff(seg, axis=0)).sum(-1)
            trim = max(1, len(step) // 20)  # końce paska bywają obramowane
            smooth = np.percentile(step[trim:-trim] if len(step) > 3 * trim else step, 95) < 60
            # pasek skali to płynny gradient: zmiana koloru rozłożona na większość długości,
            # a nie skupiona na kilku krawędziach (jak np. tułów na tle)
            sm = cv2.GaussianBlur(seg.astype(np.float32)[:, None], (1, 7), 0)[:, 0]
            st = np.abs(np.diff(sm, axis=0)).sum(-1)
            graded = np.mean(st > 0.25 * st.mean()) > 0.5 if st.size else False
            if span < 150 or not smooth or not graded:
                run = []
                continue
            run.append((x, best_s, best_len))
            if len(run) >= 2:
                xs = [r[0] for r in run]
                ys = int(np.median([r[1] for r in run]))
                ln = int(np.median([r[2] for r in run]))
                # pasek ma wyraźne krawędzie po obu stronach na większości długości
                a0, a1 = xs[0], xs[-1]
                if a0 >= 3 and a1 + 3 < arr.shape[1]:
                    inner = arr[ys:ys + ln, (a0 + a1) // 2]
                    el = np.abs(inner - arr[ys:ys + ln, a0 - 3]).sum(-1)
                    er = np.abs(inner - arr[ys:ys + ln, a1 + 3]).sum(-1)
                    edge_frac = float(np.mean(np.minimum(el, er) > 30))
                else:
                    edge_frac = 0.0
                if edge_frac >= 0.5:
                    cand = (edge_frac * ln, a0, a1, ys, ys + ln, orient)
                    if best is None or cand[0] > best[0]:
                        best = cand

    # lekkie rozmycie WZDŁUŻ paska usuwa szum JPEG, nie mieszając paska z obramowaniem
    img_v = cv2.blur(bgr, (1, 5)).astype(np.int16)
    img_h = cv2.blur(bgr, (5, 1)).astype(np.int16)
    margin_v = range(int(w * 0.70), w)
    scan(img_v, h, margin_v, "vertical")
    scan(img_h.transpose(1, 0, 2), w, range(int(h * 0.70), h), "horizontal")
    margin_l = range(0, int(w * 0.30))
    scan(img_v, h, margin_l, "vertical")

    if best is None:
        return None
    _, a0, a1, b0, b1, orient = best
    # Doprecyzuj krańce paska: pasek ma wyraźną krawędź z boku na całej długości, tło nie.
    arr = img if orient == "vertical" else img.transpose(1, 0, 2)
    W2 = arr.shape[1]
    el = np.abs(arr[:, a0] - arr[:, max(0, a0 - 3)]).sum(-1) if a0 >= 3 else np.zeros(arr.shape[0])
    er = np.abs(arr[:, a1] - arr[:, min(W2 - 1, a1 + 3)]).sum(-1) if a1 + 3 < W2 else np.zeros(arr.shape[0])
    # obie krawędzie naraz (tekst przy pasku daje krawędź tylko z jednej strony);
    # przerwy w środku (kolor paska = kolor tła) łatamy zamknięciem morfologicznym
    edge = (np.minimum(el, er)[b0:b1] > 30).astype(np.uint8)
    kl = max(9, int(0.2 * (b1 - b0)) | 1)
    edge = np.pad(edge, (kl, kl))
    edge = cv2.morphologyEx(edge[:, None], cv2.MORPH_CLOSE, np.ones((kl, 1), np.uint8))[kl:-kl, 0] > 0
    if edge.any():
        best_len, best_s, cur, s = 0, 0, 0, 0
        for i, ok in enumerate(edge):
            if ok:
                s = i if cur == 0 else s
                cur += 1
                if cur > best_len:
                    best_len, best_s = cur, s
            else:
                cur = 0
        if best_len > 0.3 * (b1 - b0):
            b0, b1 = b0 + best_s, b0 + best_s + best_len
    # przytnij krańce paska (często ramka/obwódka)
    pad = 1
    b0, b1 = b0 + pad, b1 - pad
    mid = (a0 + a1) // 2
    if orient == "vertical":
        strip = bgr[b0:b1, max(a0, mid - 1):min(a1, mid + 1) + 1].astype(np.float32).mean(1)
        x0, y0, x1, y1 = a0, b0, a1 + 1, b1
    else:
        strip = bgr[max(a0, mid - 1):min(a1, mid + 1) + 1, b0:b1].astype(np.float32).mean(0)
        x0, y0, x1, y1 = b0, a0, b1, a1 + 1
    pal_bgr = strip.astype(np.uint8)
    # orientacja: który koniec jest „gorący”? Domyślnie: góra / prawa strona.
    # Heurystyka: gorący koniec jest jaśniejszy (prawie zawsze prawda dla iron/rainbow/hot).
    lum = cv2.cvtColor(pal_bgr[None], cv2.COLOR_BGR2GRAY)[0].astype(np.float32)
    if hot_end == "auto":
        first_hot = lum[: len(lum) // 5].mean() > lum[-len(lum) // 5:].mean()
    else:
        first_hot = hot_end in ("top", "left")
    if first_hot:
        pal_bgr = pal_bgr[::-1]
    pal_rgb = pal_bgr[:, ::-1].copy()
    # wygładź i przepróbkuj do 256
    idx = np.linspace(0, len(pal_rgb) - 1, 256)
    pal_rgb = np.stack([np.interp(idx, np.arange(len(pal_rgb)), pal_rgb[:, c]) for c in range(3)], 1)
    return ColorBar(x0, y0, x1, y1, orient, pal_rgb.astype(np.uint8))


def find_overlay_boxes(bgr: np.ndarray) -> np.ndarray:
    """Maska nakładek kamery: czarne prostokąty z białym tekstem (wartość punktu, skala).
    Biały tekst wygląda jak „najgorętszy” kolor palety, więc trzeba go wykluczyć z pomiaru."""
    H, W = bgr.shape[:2]
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    dark = (hsv[..., 2] < 40)
    white = (hsv[..., 2] > 190) & (hsv[..., 1] < 60)
    both = (dark | white).astype(np.uint8)
    out = np.zeros((H, W), bool)
    n, lab, st, _ = cv2.connectedComponentsWithStats(both, 8)
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if a < 40 or w * h > 0.06 * H * W or w < 8 or h < 6:
            continue
        roi = lab[y:y + h, x:x + w] == i
        if roi.mean() < 0.85:
            continue
        wf = white[y:y + h, x:x + w][roi].mean()
        if 0.03 < wf < 0.6:
            out[max(0, y - 2):y + h + 2, max(0, x - 2):x + w + 2] = True
    return out


def choose_builtin_palette(bgr: np.ndarray, mask: Optional[np.ndarray] = None) -> PaletteMapper:
    """Wybiera wbudowaną paletę o najmniejszym średnim błędzie dopasowania kolorów."""
    small = cv2.resize(bgr, (min(160, bgr.shape[1]), min(120, bgr.shape[0])), interpolation=cv2.INTER_AREA)
    m = None if mask is None else cv2.resize(mask.astype(np.uint8), small.shape[1::-1], interpolation=cv2.INTER_NEAREST) > 0
    best = None
    for name, pal in builtin_palettes().items():
        pm = PaletteMapper(pal, name)
        _, err = pm.map_fast(small)
        e = float(np.median(err[m] if m is not None else err))
        if best is None or e < best[0]:
            best = (e, pm)
    return best[1]


# ----------------------------------------------------------------------------
# Konwersja na temperaturę
# ----------------------------------------------------------------------------

@dataclass
class ScaleConfig:
    tmin: Optional[float] = None   # None = odczyt z obrazu (liczby przy pasku skali)
    tmax: Optional[float] = None
    palette: str = "auto"          # auto | bar | nazwa wbudowanej
    bar_hot_end: str = "auto"      # auto | top | bottom | left | right
    gray_invert: str = "auto"      # auto | yes | no
    gray_gain: Optional[float] = None   # dla danych radiometrycznych 16-bit
    gray_offset: float = 0.0
    emissivity: float = 1.0        # 1.0 = brak korekcji (kamera zwykle już ją stosuje)
    reflected_temp: float = 22.0
    overlay_err: float = 22.0      # próg błędu Lab, powyżej którego piksel to nakładka (tekst, ramki)


def emissivity_correct(t: np.ndarray, eps: float, t_refl: float) -> np.ndarray:
    """Przybliżona korekcja emisyjności (model szerokopasmowy Stefana-Boltzmanna)."""
    if eps >= 0.999:
        return t
    tk = t + 273.15
    rk = t_refl + 273.15
    obj4 = (tk ** 4 - (1 - eps) * rk ** 4) / eps
    return np.power(np.clip(obj4, 1, None), 0.25) - 273.15


def _plausible_scale(lo: float, hi: float) -> bool:
    """Odrzuca oczywiście błędne odczyty OCR (np. zamienione lub sklejone liczby)."""
    return -60.0 <= lo < hi <= 2200.0 and 0.5 <= hi - lo <= 500.0


class ThermalConverter:
    def __init__(self, cfg: ScaleConfig):
        self.cfg = cfg
        self.mapper: Optional[PaletteMapper] = None
        self.colorbar: Optional[ColorBar] = None
        self.gray_inverted: Optional[bool] = None
        self.notes: list[str] = []

    # --- kolor ---
    def init_color(self, bgr: np.ndarray):
        cfg = self.cfg
        if cfg.palette in ("auto", "bar"):
            self.colorbar = detect_colorbar(bgr, cfg.bar_hot_end)
            if self.colorbar is not None:
                self.mapper = PaletteMapper(self.colorbar.palette_rgb, "z paska skali")
                self.notes.append(f"Wykryto pasek skali ({self.colorbar.orientation}) w "
                                  f"x={self.colorbar.x0}..{self.colorbar.x1}, y={self.colorbar.y0}..{self.colorbar.y1}; paleta odczytana z paska.")
            elif cfg.palette == "bar":
                self.notes.append("Nie znaleziono paska skali – używam palety wbudowanej.")
        self.overlay = find_overlay_boxes(bgr)
        self.resolve_scale(bgr)
        if self.mapper is None:
            if cfg.palette in builtin_palettes():
                self.mapper = PaletteMapper(builtin_palettes()[cfg.palette], cfg.palette)
            else:
                self.mapper = choose_builtin_palette(bgr)
            self.notes.append(f"Paleta: {self.mapper.name}.")

    def resolve_scale(self, img: np.ndarray):
        """Ustala tmin/tmax: z parametrów, a jeśli ich brak – z liczb przy pasku skali."""
        cfg = self.cfg
        if cfg.tmin is not None and cfg.tmax is not None:
            return
        bgr = img if img.ndim == 3 else cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
        bar = self.colorbar or detect_colorbar(bgr, cfg.bar_hot_end)
        res = scale_ocr.read_scale(bgr, bar) if bar is not None else None
        if res and not _plausible_scale(res[0], res[1]):
            res = None
        self.scale_auto = (cfg.tmin is None, cfg.tmax is None)
        self.scale_ok = bool(res)
        if res:
            lo, hi, txt = res
            self.scale_bar = bar
            self._scale_sig = self._label_signature(bgr, bar)
            cfg.tmin = lo if cfg.tmin is None else cfg.tmin
            cfg.tmax = hi if cfg.tmax is None else cfg.tmax
            self.notes.append(f"Skala {cfg.tmin:g}…{cfg.tmax:g} °C {txt}. Sprawdź, czy zgadza się z obrazem.")
        else:
            cfg.tmin = 20.0 if cfg.tmin is None else cfg.tmin
            cfg.tmax = 40.0 if cfg.tmax is None else cfg.tmax
            self.notes.append(f"UWAGA: nie udało się odczytać skali z obrazu – przyjęto {cfg.tmin:g}…{cfg.tmax:g} °C. "
                              "Wpisz właściwe wartości ręcznie.")
            self._fallback_note = len(self.notes) - 1

    def find_scale(self, bgr: np.ndarray) -> bool:
        """Film, w którym skali nie udało się odczytać od razu (np. pasek zlał się z jasną sceną):
        szukamy paska i liczb w kolejnych klatkach. Zwraca True, gdy skala została odczytana."""
        cfg = self.cfg
        bar = detect_colorbar(bgr, cfg.bar_hot_end)
        res = scale_ocr.read_scale(bgr, bar) if bar is not None else None
        if not res or not _plausible_scale(res[0], res[1]):
            return False
        lo, hi, txt = res
        auto = getattr(self, "scale_auto", (True, True))
        if auto[0]:
            cfg.tmin = lo
        if auto[1]:
            cfg.tmax = hi
        self.scale_ok = True
        self.scale_bar = bar
        self._scale_sig = self._label_signature(bgr, bar)
        if self.mapper is not None and cfg.palette in ("auto", "bar") and self.colorbar is None:
            # obraz kolorowy: paleta odczytana z paska jest dokładniejsza niż wbudowana
            self.colorbar = bar
            self.mapper = PaletteMapper(bar.palette_rgb, "z paska skali")
        fb = getattr(self, "_fallback_note", None)
        if fb is not None and fb < len(self.notes):
            self.notes[fb] = (f"Skala {cfg.tmin:g}…{cfg.tmax:g} °C odczytana dopiero z dalszej klatki filmu – "
                              "klatki przed nią pominięto w średnich (nie było w nich czytelnej skali).")
            self._fallback_note = None
        return True

    @staticmethod
    def _label_signature(bgr: np.ndarray, bar) -> Optional[np.ndarray]:
        """Wycinek obrazu z liczbami przy końcach paska skali (do wykrycia zmiany skali w filmie)."""
        if bar is None:
            return None
        H, W = bgr.shape[:2]
        if bar.orientation == "vertical":
            m = max(40, int(0.15 * W))
            xa, xb = max(0, bar.x0 - m), min(W, bar.x1 + m)
            parts = [bgr[max(0, bar.y0 - int(0.15 * H)):bar.y0 + 2, xa:xb], bgr[bar.y1 - 2:min(H, bar.y1 + int(0.15 * H)), xa:xb]]
        else:
            m = max(30, int(0.12 * H))
            ya, yb = max(0, bar.y0 - m), min(H, bar.y1 + m)
            parts = [bgr[ya:yb, max(0, bar.x0 - int(0.2 * W)):bar.x0 + 2], bgr[ya:yb, bar.x1 - 2:min(W, bar.x1 + int(0.2 * W))]]
        return np.concatenate([cv2.cvtColor(p, cv2.COLOR_BGR2GRAY).ravel() for p in parts if p.size]).astype(np.int16)

    def update_scale(self, bgr: np.ndarray):
        """Kamera z automatyczną skalą zmienia liczby przy pasku w trakcie nagrania – sprawdzamy je
        w każdej klatce. Pasek nie zmienia położenia, więc liczby czytamy przy pasku znalezionym
        w dobrej klatce (nawet gdy w bieżącej klatce jasna scena zlewa się z paskiem)."""
        auto = getattr(self, "scale_auto", (False, False))
        if not any(auto):
            return
        self._frame_no = getattr(self, "_frame_no", 0) + 1
        if not getattr(self, "scale_ok", False) or getattr(self, "_scale_sig", None) is None:
            if self._frame_no % 3 == 1:  # szukanie paska jest wolniejsze – co 3. klatkę
                self.find_scale(bgr)
            return
        sig = self._label_signature(bgr, self.scale_bar)
        if sig is None or sig.shape != self._scale_sig.shape:
            return
        pending = getattr(self, "_pending", None)
        if np.abs(sig - self._scale_sig).mean() < 2 and not getattr(self, "_last_read_failed", False) and pending is None:
            return
        res = scale_ocr.read_scale(bgr, self.scale_bar)
        if not res or not _plausible_scale(res[0], res[1]):
            # liczb nie da się teraz odczytać – zostaje ostatnia poprawnie odczytana skala
            self._last_read_failed = True
            self.scale_read_failures = getattr(self, "scale_read_failures", 0) + 1
            return
        self._last_read_failed = False
        lo, hi, _ = res
        new = (lo if auto[0] else self.cfg.tmin, hi if auto[1] else self.cfg.tmax)
        big_jump = abs(new[0] - self.cfg.tmin) > 15 or abs(new[1] - self.cfg.tmax) > 15
        if big_jump and pending != new:
            # podejrzanie duża zmiana musi się powtórzyć w następnej klatce – pojedyncza pomyłka OCR jej nie zmieni
            self._pending = new
            return
        self._pending = None
        self._scale_sig = sig
        old = (self.cfg.tmin, self.cfg.tmax)
        if auto[0]:
            self.cfg.tmin = lo
        if auto[1]:
            self.cfg.tmax = hi
        if (self.cfg.tmin, self.cfg.tmax) != old:
            self.scale_changes = getattr(self, "scale_changes", 0) + 1
            self.scale_history = getattr(self, "scale_history", [])
            self.scale_history.append((self.cfg.tmin, self.cfg.tmax))

    def color_to_temp(self, bgr: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Zwraca (temperatura °C, maska wiarygodnych pikseli)."""
        if self.mapper is None:
            self.init_color(bgr)
        else:
            self.update_scale(bgr)
        v, err = self.mapper.map(bgr)
        t = self.cfg.tmin + v * (self.cfg.tmax - self.cfg.tmin)
        valid = err < self.cfg.overlay_err
        if getattr(self, "overlay", None) is not None and self.overlay.shape == valid.shape:
            valid &= ~self.overlay
        if self.colorbar is not None:
            cb = self.colorbar
            valid[max(0, cb.y0 - 4):cb.y1 + 4, max(0, cb.x0 - 4):cb.x1 + 4] = False
        return t.astype(np.float32), valid

    # --- szarość ---
    def gray_to_temp(self, gray_img: np.ndarray, ref_temp: Optional[np.ndarray] = None,
                     ref_valid: Optional[np.ndarray] = None) -> np.ndarray:
        cfg = self.cfg
        if gray_img.ndim == 3:
            g = cv2.cvtColor(gray_img, cv2.COLOR_BGR2GRAY)
        else:
            g = gray_img
        if cfg.gray_gain is not None:
            return (g.astype(np.float32) * cfg.gray_gain + cfg.gray_offset).astype(np.float32)
        if cfg.tmin is None or cfg.tmax is None:
            self.resolve_scale(g)
        elif self.mapper is None:  # sam obraz szary z paskiem skali: skala może się zmieniać w filmie
            self.update_scale(cv2.cvtColor(g, cv2.COLOR_GRAY2BGR) if g.dtype == np.uint8 else cv2.cvtColor(
                cv2.normalize(g, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8), cv2.COLOR_GRAY2BGR))
        maxv = 65535.0 if g.dtype == np.uint16 else 255.0
        v = g.astype(np.float32) / maxv
        if self.gray_inverted is None:
            if cfg.gray_invert == "yes":
                self.gray_inverted = True
            elif cfg.gray_invert == "no":
                self.gray_inverted = False
            elif ref_temp is not None:
                m = ref_valid if ref_valid is not None else np.ones_like(v, bool)
                c = np.corrcoef(v[m].ravel(), ref_temp[m].ravel())[0, 1] if m.sum() > 100 else 1.0
                self.gray_inverted = bool(c < 0)
                if self.gray_inverted:
                    self.notes.append("Obraz szary wygląda na 'black-hot' (korelacja ujemna) – odwrócono.")
            else:
                self.gray_inverted = False
        if self.gray_inverted:
            v = 1.0 - v
        return (cfg.tmin + v * (cfg.tmax - cfg.tmin)).astype(np.float32)

    def finalize(self, t: np.ndarray) -> np.ndarray:
        return emissivity_correct(t, self.cfg.emissivity, self.cfg.reflected_temp)


# ----------------------------------------------------------------------------
# Detekcja ciała i twarzy
# ----------------------------------------------------------------------------

@dataclass
class DetectConfig:
    body_tmin: float = 28.0
    body_tmax: float = 42.0
    min_body_frac: float = 0.005
    yunet_model: Optional[str] = None
    yolo_model: Optional[str] = None
    thermal_yolo: bool = True      # dodatkowe warianty obrazu dla YOLO (termowizja), przybliżenie głowy, śledzenie w filmie
    yolo_conf_thermal: float = 0.25
    track_frames: int = 15         # ile klatek bez detekcji YOLO można utrzymać ostatnią twarz (film)
    body_fallback: bool = True     # głowa z sylwetki, gdy detektory nie widzą twarzy (w filmie z YOLO wyłączone)


def resource_path(name: str) -> Optional[str]:
    """Szuka pliku obok programu (.exe), w paczce PyInstallera i obok skryptu."""
    dirs = []
    if getattr(sys, "frozen", False):
        dirs.append(os.path.dirname(sys.executable))
        dirs.append(getattr(sys, "_MEIPASS", ""))
    dirs.append(os.path.dirname(os.path.abspath(__file__)))
    dirs.append(os.getcwd())
    for d in dirs:
        p = os.path.join(d, name)
        if d and os.path.exists(p):
            return p
    return None


class YoloFace:
    """Detektor twarzy YOLOv8-face (ONNX, z wbudowanym NMS; wyjście 1x300x21) przez onnxruntime."""

    def __init__(self, model_path: str, conf: float = 0.35):
        import onnxruntime as ort
        self.sess = ort.InferenceSession(model_path, providers=["CPUExecutionProvider"])
        inp = self.sess.get_inputs()[0]
        self.name = inp.name
        self.size = int(inp.shape[2]) if isinstance(inp.shape[2], int) else 640
        self.conf = conf

    def detect(self, gray8: np.ndarray, conf: Optional[float] = None):
        conf = self.conf if conf is None else conf
        h, w = gray8.shape[:2]
        img = cv2.cvtColor(gray8, cv2.COLOR_GRAY2BGR) if gray8.ndim == 2 else gray8
        S = self.size
        r = min(S / w, S / h)
        nw, nh = int(round(w * r)), int(round(h * r))
        canvas = np.full((S, S, 3), 114, np.uint8)
        px, py = (S - nw) // 2, (S - nh) // 2
        canvas[py:py + nh, px:px + nw] = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_LINEAR)
        blob = canvas[..., ::-1].transpose(2, 0, 1)[None].astype(np.float32) / 255.0
        out = self.sess.run(None, {self.name: blob})[0][0]
        faces = []
        for d in out:
            if d[4] < conf:
                continue
            x1, y1, x2, y2 = (d[0] - px) / r, (d[1] - py) / r, (d[2] - px) / r, (d[3] - py) / r
            x1, y1, x2, y2 = max(0, x1), max(0, y1), min(w, x2), min(h, y2)
            if x2 - x1 > 3 and y2 - y1 > 3:
                faces.append((int(x1), int(y1), int(x2 - x1), int(y2 - y1), "yolo", float(d[4])))
        return faces


class FaceDetector:
    def __init__(self, cfg: DetectConfig):
        self.cfg = cfg
        hd = cv2.data.haarcascades
        self.frontal = [cv2.CascadeClassifier(os.path.join(hd, f)) for f in
                        ("haarcascade_frontalface_default.xml", "haarcascade_frontalface_alt2.xml")]
        self.profile = cv2.CascadeClassifier(os.path.join(hd, "haarcascade_profileface.xml"))
        self.yolo = None
        self.yolo_note = None
        if cfg.yolo_model:
            try:
                self.yolo = YoloFace(cfg.yolo_model)
                self.yolo_note = f"Detektor twarzy: YOLO ({os.path.basename(cfg.yolo_model)}), zapasowo Haar i sylwetka."
            except Exception as e:  # brak onnxruntime albo zły plik – działamy dalej bez YOLO
                self.yolo_note = f"YOLO niedostępne ({type(e).__name__}: {e}); używam Haar i sylwetki."
        self.yunet = None
        if cfg.yunet_model and os.path.exists(cfg.yunet_model):
            self.yunet = cv2.FaceDetectorYN.create(cfg.yunet_model, "", (320, 320), 0.6, 0.3, 50)

    def detect(self, gray8: np.ndarray, temp: np.ndarray, body_mask: np.ndarray, detail=None,
               color: Optional[np.ndarray] = None):
        """Zwraca listę (x, y, w, h, metoda) we współrzędnych mapy temperatur, od największej twarzy.

        detail = (obraz8 w wysokiej rozdzielczości, Alignment) – wtedy twarz jest szukana najpierw
        na dokładniejszym obrazie i przenoszona na mapę temperatur."""
        cands = []
        if detail is not None:
            img8, al = detail
            k = min(1.0, 1024.0 / max(img8.shape[:2]))
            small = cv2.resize(img8, None, fx=k, fy=k, interpolation=cv2.INTER_AREA) if k < 1 else img8
            for (x, y, fw, fh, m, *cf) in self._raw_detect(small):  # YOLO dodaje 6. pole: pewność
                bx = al.box_to_thermal((x / k, y / k, fw / k, fh / k))
                if bx is not None:
                    cands.append((*bx, m + "-hires", *cf[:1]))
        good = self._validate(cands, temp, body_mask)
        if not good:
            good = self._validate(self._yolo_thermal(temp, body_mask, color), temp, body_mask)
        if not good:
            good = self._validate(self._raw_detect(gray8), temp, body_mask)
        if self.cfg.thermal_yolo:
            good = self._track(good, temp, body_mask)
        if not good and self.cfg.body_fallback:
            hb = head_from_body(body_mask, temp)
            if hb is not None:
                good = [hb]
        # najpierw twarz, która jest najbardziej „skórą” (ciepła, w sylwetce), dopiero potem największa
        return sorted(good, key=lambda f: -self._skin_score(f, temp, body_mask))

    # ---------------------------------------------------------------- YOLO na termowizji
    @staticmethod
    def skin_window(temp: np.ndarray, body_mask: Optional[np.ndarray]) -> np.ndarray:
        """Obraz 8-bit z wąskim oknem temperatur wokół skóry (ok. 8 °C poniżej najcieplejszych miejsc ciała).
        Na pełnej skali twarz jest jednolicie jasna; w wąskim oknie widać oczy, nos, usta i włosy –
        tego potrzebuje YOLO, które uczono na zwykłych zdjęciach."""
        src = temp[body_mask] if body_mask is not None and body_mask.sum() > 50 else temp.ravel()
        hi = float(np.percentile(src, 99.5))
        lo = hi - 8.0
        v = np.clip((temp - lo) / (hi - lo), 0, 1)
        g = (v * 255).astype(np.uint8)
        return cv2.createCLAHE(2.0, (8, 8)).apply(g)

    def _yolo_thermal(self, temp, body_mask, color):
        """Kolejne próby YOLO dopasowane do termowizji; kończy na pierwszej udanej."""
        if self.yolo is None or not self.cfg.thermal_yolo:
            return []
        c = self.cfg.yolo_conf_thermal
        win = self.skin_window(temp, body_mask)
        tries = [(win, "yolo-okno")]
        if color is not None and color.ndim == 3 and color.shape[:2] == temp.shape[:2]:
            tries.append((color, "yolo-paleta"))
        for img, m in tries:
            f = self.yolo.detect(img, c)
            if f:
                return [(x, y, w, h, m, cf) for (x, y, w, h, _, cf) in f]
        # mała twarz (daleko od kamery): przybliżenie okolicy głowy z sylwetki
        hb = head_from_body(body_mask, temp) if body_mask is not None and body_mask.any() else None
        if hb is not None:
            H, W = temp.shape
            x, y, w, h = hb[:4]
            s = max(w, h) * 1.6
            cx, cy = x + w / 2, y + h / 2
            x0, y0 = int(max(0, cx - s / 2)), int(max(0, cy - s / 2))
            x1, y1 = int(min(W, cx + s / 2)), int(min(H, cy + s / 2))
            if x1 - x0 >= 16 and y1 - y0 >= 16 and (x1 - x0) * (y1 - y0) < 0.5 * H * W:
                crop = win[y0:y1, x0:x1]
                k = max(1.0, 320.0 / max(crop.shape))
                crop = cv2.resize(crop, None, fx=k, fy=k, interpolation=cv2.INTER_CUBIC)
                f = self.yolo.detect(crop, c)
                if f:
                    return [(int(x0 + fx / k), int(y0 + fy / k), int(fw / k), int(fh / k), "yolo-zoom", cf)
                            for (fx, fy, fw, fh, _, cf) in f]
        return []

    def _track(self, good, temp, body_mask):
        """Film: gdy YOLO w tej klatce nie znalazło twarzy, a znalazło ją niedawno, szukamy tej samej twarzy
        w pobliżu (dopasowanie wzorca temperatur z ostatniej klatki YOLO). Ramka idzie za twarzą; gdy kadr
        się zmienił (inny fragment ciała, ruch kamery), dopasowanie jest słabe i śledzenie się kończy."""
        top = max(good, key=lambda f: self._skin_score(f, temp, body_mask)) if good else None
        H, W = temp.shape
        if top is not None and str(top[4]).startswith("yolo"):
            x, y, w, h = [int(v) for v in top[:4]]
            x0, y0, x1, y1 = max(0, x), max(0, y), min(W, x + w), min(H, y + h)
            self._last_yolo, self._yolo_age = None, 0
            if x1 - x0 >= 8 and y1 - y0 >= 8:
                self._last_yolo = ((x0, y0, x1 - x0, y1 - y0), temp[y0:y1, x0:x1].astype(np.float32).copy())
            return good
        last = getattr(self, "_last_yolo", None)
        if last is None:
            return good
        self._yolo_age = getattr(self, "_yolo_age", 0) + 1
        if self._yolo_age > self.cfg.track_frames:
            self._last_yolo = None
            return good
        (x, y, w, h), tmpl = last
        mx, my = int(0.6 * w), int(0.6 * h)
        sx0, sy0, sx1, sy1 = max(0, x - mx), max(0, y - my), min(W, x + w + mx), min(H, y + h + my)
        region = temp[sy0:sy1, sx0:sx1].astype(np.float32)
        if region.shape[0] < h or region.shape[1] < w or float(tmpl.std()) < 0.05:
            self._last_yolo = None
            return good
        res = cv2.matchTemplate(region, tmpl, cv2.TM_CCOEFF_NORMED)
        _, score, _, loc = cv2.minMaxLoc(res)
        if score < 0.6:  # to już nie ta twarz
            self._last_yolo = None
            return good
        tr = (sx0 + loc[0], sy0 + loc[1], w, h, "yolo-sledzenie")
        if self._validate([tr], temp, body_mask):
            return [tr]
        self._last_yolo = None
        return good

    def _skin_stats(self, f, temp, body_mask):
        H, W = temp.shape
        x, y, fw, fh = f[:4]
        x0, y0, x1, y1 = max(0, x), max(0, y), min(W, x + fw), min(H, y + fh)
        roi = temp[y0:y1, x0:x1]
        if roi.size == 0:
            return 0.0, 0.0, -273.0
        skin = (roi >= self.cfg.body_tmin + 2) & (roi <= self.cfg.body_tmax)
        inbody = float(body_mask[y0:y1, x0:x1].mean()) if body_mask is not None and body_mask.any() else 1.0
        return float(skin.mean()), inbody, float(np.percentile(roi, 75))

    def _skin_score(self, f, temp, body_mask):
        frac, inbody, _ = self._skin_stats(f, temp, body_mask)
        return frac * inbody * np.sqrt(max(1, f[2] * f[3]))

    def _validate(self, faces, temp, body_mask=None):
        # twarz musi być ciepła i leżeć na sylwetce – odrzuca trafienia na ścianie, meblach itp.
        good = []
        for f in faces:
            frac, inbody, p75 = self._skin_stats(f, temp, body_mask)
            if p75 >= self.cfg.body_tmin + 2 and frac >= 0.35 and inbody >= 0.4:
                good.append(f)
        return nms(good)

    def _raw_detect(self, gray8: np.ndarray):
        h, w = gray8.shape
        faces: list[tuple[int, int, int, int, str]] = []
        eq = cv2.createCLAHE(2.0, (8, 8)).apply(gray8)
        if self.yolo is not None:
            for img in (eq, 255 - eq):  # twarz w termowizji bywa jasna albo ciemna
                faces = list(self.yolo.detect(img))
                if faces:
                    return faces
        if self.yunet is not None:
            self.yunet.setInputSize((w, h))
            _, det = self.yunet.detect(cv2.cvtColor(eq, cv2.COLOR_GRAY2BGR))
            if det is not None:
                for d in det:
                    faces.append((int(d[0]), int(d[1]), int(d[2]), int(d[3]), "yunet"))
        if not faces:
            minsz = max(20, int(min(h, w) * 0.06))
            for img in (eq, 255 - eq):
                for c in self.frontal:
                    for (x, y, fw, fh) in c.detectMultiScale(img, 1.1, 5, minSize=(minsz, minsz)):
                        faces.append((int(x), int(y), int(fw), int(fh), "haar-frontal"))
                if faces:
                    break
            if not faces:
                for img in (eq, cv2.flip(eq, 1)):
                    flipped = img is not eq
                    for (x, y, fw, fh) in self.profile.detectMultiScale(img, 1.1, 5, minSize=(minsz, minsz)):
                        if flipped:
                            x = w - x - fw
                        faces.append((int(x), int(y), int(fw), int(fh), "haar-profil"))
        return faces


# ----------------------------------------------------------------------------
# Dopasowanie obrazu o wysokiej rozdzielczości do mapy temperatur
# ----------------------------------------------------------------------------

class Alignment:
    """Przekształcenie afiniczne między mapą temperatur (np. 320x240) a obrazem szczegółowym
    (np. 2048x1536). T2D: współrzędne termiczne -> szczegółowe (macierz 3x3)."""

    def __init__(self, T2D: np.ndarray, thermal_shape, detail_shape, score: float, method: str):
        self.T2D = T2D
        self.D2T = np.linalg.inv(T2D)
        self.tshape, self.dshape = thermal_shape[:2], detail_shape[:2]
        self.score, self.method = score, method
        self.detail_is_palette = False

    @staticmethod
    def _box(M, box, shape, min_inside: float = 0.0):
        x, y, w, h = box
        pts = np.array([[x, y, 1], [x + w, y, 1], [x, y + h, 1], [x + w, y + h, 1]], np.float64).T
        q = (M @ pts)[:2]
        x0, y0 = q.min(1)
        x1, y1 = q.max(1)
        area = max(1e-6, (x1 - x0) * (y1 - y0))
        H, W = shape
        x0, y0, x1, y1 = max(0, x0), max(0, y0), min(W, x1), min(H, y1)
        if x1 - x0 < 2 or y1 - y0 < 2 or (x1 - x0) * (y1 - y0) < min_inside * area:
            return None
        return int(round(x0)), int(round(y0)), int(round(x1 - x0)), int(round(y1 - y0))

    def box_to_thermal(self, box):
        # twarz znaleziona na zdjęciu musi w większości leżeć w polu widzenia kamery termowizyjnej
        return self._box(self.D2T, box, self.tshape, 0.6)

    def thermal_frame(self):
        """Prostokąt pola termowizyjnego na obrazie szczegółowym (x0, y0, x1, y1)."""
        Ht, Wt = self.tshape
        p = self.T2D @ np.array([[0, Wt], [0, Ht], [1, 1]], np.float64)
        return int(round(p[0, 0])), int(round(p[1, 0])), int(round(p[0, 1])), int(round(p[1, 1]))

    def box_to_detail(self, box):
        return self._box(self.T2D, box, self.dshape)

    def mask_to_detail(self, mask: np.ndarray) -> np.ndarray:
        H, W = self.dshape
        return cv2.warpAffine(mask.astype(np.uint8), self.T2D[:2].astype(np.float32), (W, H),
                              flags=cv2.INTER_NEAREST) > 0


def detail_value_map(detail_bgr: np.ndarray):
    """Obraz szczegółowy -> (wartość 0..1 rosnąca z temperaturą lub jasność, czy_paleta)."""
    if detail_bgr.ndim == 2:
        g = detail_bgr
        return (g.astype(np.float32) / (65535.0 if g.dtype == np.uint16 else 255.0)), False
    sat = cv2.cvtColor(detail_bgr, cv2.COLOR_BGR2HSV)[..., 1].mean()
    if sat < 25:  # w praktyce obraz szary zapisany jako kolorowy
        return cv2.cvtColor(detail_bgr, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0, False
    pm = choose_builtin_palette(detail_bgr)
    v, _ = pm.map_fast(detail_bgr)
    return v.astype(np.float32), True


def _detail_candidates(detail_bgr: np.ndarray):
    """Wersje obrazu szczegółowego do porównania z mapą temperatur: (nazwa, obraz 0..1, czy_paleta)."""
    out = []
    if detail_bgr.ndim == 2:
        g = detail_bgr
        if g.dtype != np.uint8:
            g = cv2.normalize(g, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    else:
        g = cv2.cvtColor(detail_bgr, cv2.COLOR_BGR2GRAY)
        if cv2.cvtColor(detail_bgr, cv2.COLOR_BGR2HSV)[..., 1].mean() >= 25:
            pm = choose_builtin_palette(detail_bgr)
            v, _ = pm.map_fast(detail_bgr)
            out.append(("paleta", v.astype(np.float32), True))
    # zwykłe zdjęcie: jasność po wyrównaniu kontrastu (ciepłe miejsca bywają jasne albo ciemne)
    eq = cv2.createCLAHE(3.0, (8, 8)).apply(g).astype(np.float32) / 255.0
    out.append(("zdjęcie", eq, False))
    out.append(("zdjęcie-odwr.", 1.0 - eq, False))
    return out


def _match_scales(dimg: np.ndarray, timg: np.ndarray, widths, Wd: int):
    """Szuka miejsca, w którym mapa temperatur (timg) pasuje do obrazu dimg, dla kolejnych
    szerokości pola termowizyjnego na obrazie szczegółowym. Zwraca (wynik, szerokość, x0, y0)."""
    best = (-1.0, 0.0, 0.0, 0.0)
    tb = cv2.GaussianBlur(timg, (0, 0), 1.2)
    for wd in widths:
        f = timg.shape[1] / float(wd)
        ds = cv2.resize(dimg, (max(1, int(round(Wd * f))), max(1, int(round(dimg.shape[0] * Wd / dimg.shape[1] * f)))),
                        interpolation=cv2.INTER_AREA)
        if ds.shape[0] < timg.shape[0] or ds.shape[1] < timg.shape[1]:
            continue
        r = cv2.matchTemplate(cv2.GaussianBlur(ds, (0, 0), 1.2), tb, cv2.TM_CCOEFF_NORMED)
        _, mx, _, loc = cv2.minMaxLoc(r)
        if mx > best[0]:
            best = (float(mx), float(wd), loc[0] / f, loc[1] / f)
    return best


def estimate_alignment(temp: np.ndarray, detail_bgr: np.ndarray, notes: list,
                       hint: Optional[tuple] = None) -> Alignment:
    """Położenie mapy temperatur na obrazie szczegółowym.

    Zdjęcie zwykłe (wizyjne) ma zwykle szersze pole widzenia, a obraz termowizyjny jest jego
    wycinkiem. Program szuka więc skali i przesunięcia wycinka (porównanie kształtów na wielu skalach),
    najpierw zgrubnie, potem dokładnie. hint = (x0, y0, szerokość) w pikselach obrazu szczegółowego,
    np. z danych PiP kamery FLIR; wtedy wynik jest tylko doprecyzowywany wokół niego."""
    Ht, Wt = temp.shape
    Hd, Wd = detail_bgr.shape[:2]
    tn = temp.astype(np.float32)
    tn = np.clip((tn - np.percentile(tn, 1)) / max(1e-6, np.percentile(tn, 99) - np.percentile(tn, 1)), 0, 1)
    tn = tn.astype(np.float32)
    k = min(1.0, 160.0 / Wt)
    tsm = cv2.resize(tn, None, fx=k, fy=k, interpolation=cv2.INTER_AREA) if k < 1 else tn
    full_w = min(Wd, Hd * Wt / Ht)  # największa szerokość, przy której wycinek mieści się w kadrze
    if hint is not None:
        hw = hint[2]
        coarse = np.linspace(0.9 * hw, min(full_w, 1.1 * hw), 9)
    else:
        coarse = np.linspace(0.3 * full_w, full_w, 36)
    best = None
    for name, img, is_pal in _detail_candidates(detail_bgr):
        sc, wd, x0, y0 = _match_scales(img, tsm, coarse, Wd)
        if best is None or sc > best[0]:
            best = (sc, wd, x0, y0, name, is_pal, img)
    sc, wd, x0, y0, name, is_pal, img = best
    # doprecyzowanie w pełnej rozdzielczości mapy temperatur
    step = coarse[1] - coarse[0] if len(coarse) > 1 else 0.02 * wd
    fine = np.linspace(max(0.2 * full_w, wd - step), min(full_w, wd + step), 15)
    sc2, wd2, x2, y2 = _match_scales(img, tn, fine, Wd)
    if sc2 >= sc - 0.05:
        sc, wd, x0, y0 = sc2, wd2, x2, y2
    if hint is not None and sc < 0.4:
        x0, y0, wd = hint
        method = "PiP kamery"
        notes.append(f"Położenie obrazu termowizyjnego na zdjęciu {Wd}x{Hd} wzięte z danych kamery (PiP); "
                     f"dopasowanie obrazów było słabe (zgodność {max(sc, 0):.2f}).")
    elif sc >= 0.35 or hint is not None:
        method = name
        rel = wd / Wd
        notes.append(f"Obraz termowizyjny {Wt}x{Ht} odnaleziony na zdjęciu {Wd}x{Hd}: zajmuje {rel * 100:.0f}% "
                     f"szerokości, lewy górny róg ({x0:.0f}, {y0:.0f}) (zgodność {sc:.2f}"
                     + (", z podpowiedzią PiP kamery" if hint is not None else "") + ").")
    else:
        # słaba zgodność: zakładamy, że to ten sam kadr
        x0, y0, wd = 0.0, 0.0, float(Wd)
        method = "skalowanie"
        notes.append(f"UWAGA: nie udało się odnaleźć obrazu termowizyjnego na zdjęciu {Wd}x{Hd} (zgodność {max(sc, 0):.2f}); "
                     "zakładam ten sam kadr. Twarz może być przesunięta – sprawdź podgląd.")
        is_pal = name == "paleta"
    s_ = wd / Wt
    T2D = np.array([[s_, 0, x0], [0, s_, y0], [0, 0, 1]], np.float64)
    al = Alignment(T2D, temp.shape, detail_bgr.shape, max(sc, 0.0), method)
    al.detail_is_palette = is_pal
    return al


def nms(boxes, thr=0.3):
    out = []
    for b in sorted(boxes, key=lambda f: -f[2] * f[3]):
        if all(iou(b, o) < thr for o in out):
            out.append(b)
    return out


def iou(a, b):
    ax1, ay1, ax2, ay2 = a[0], a[1], a[0] + a[2], a[1] + a[3]
    bx1, by1, bx2, by2 = b[0], b[1], b[0] + b[2], b[1] + b[3]
    ix = max(0, min(ax2, bx2) - max(ax1, bx1))
    iy = max(0, min(ay2, by2) - max(ay1, by1))
    inter = ix * iy
    return inter / float(a[2] * a[3] + b[2] * b[3] - inter + 1e-6)


def segment_body(temp: np.ndarray, valid: np.ndarray, cfg: DetectConfig) -> np.ndarray:
    m = (temp >= cfg.body_tmin) & (temp <= cfg.body_tmax) & valid
    m = m.astype(np.uint8) * 255
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, k)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9)))
    n, lab, stats, _ = cv2.connectedComponentsWithStats(m)
    keep = np.zeros_like(m, bool)
    min_area = cfg.min_body_frac * m.size
    for i in range(1, n):
        if stats[i, cv2.CC_STAT_AREA] >= min_area:
            keep |= lab == i
    return keep


def head_from_body(body: np.ndarray, temp: np.ndarray):
    """Heurystyka zapasowa: głowa = górna część największej sylwetki, do miejsca, gdzie
    sylwetka gwałtownie się poszerza (barki)."""
    m = body.astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(m)
    if n <= 1:
        return None
    i = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    comp = lab == i
    rows = np.where(comp.any(1))[0]
    top, bottom = rows[0], rows[-1]
    widths = comp.sum(1)
    head_w = None
    y_end = bottom
    for y in range(top, bottom + 1):
        wy = widths[y]
        span = y - top
        if span < 5:
            continue
        ref = np.median(widths[top + span // 3: y]) if y - (top + span // 3) > 2 else widths[top:y].max()
        if head_w is None and span > 10 and wy > 1.6 * ref:
            head_w = ref
            y_end = y
            break
    if head_w is None:  # samo zbliżenie twarzy / brak barków
        head_w = np.median(widths[top:bottom + 1][widths[top:bottom + 1] > 0])
        y_end = min(bottom, int(top + 1.35 * head_w))
    y_end = min(y_end, int(top + 1.5 * head_w))
    cols = np.where(comp[top:y_end + 1].any(0))[0]
    if len(cols) == 0:
        return None
    x0, x1 = cols[0], cols[-1]
    return (int(x0), int(top), int(x1 - x0 + 1), int(y_end - top + 1), "sylwetka-cieplna")


def face_hotspot(temp: np.ndarray, valid: np.ndarray, face, sat_level: Optional[float] = None):
    """Najcieplejszy punkt w ramce twarzy (np. wewnętrzny kącik oka). Zwraca (temp, x, y) albo None.
    Pojedyncze zaszumione piksele są tłumione lekkim wygładzeniem 3x3 przy szukaniu położenia,
    a podawana temperatura to maksimum z otoczenia 3x3 tego punktu w oryginalnych danych."""
    H, W = temp.shape
    x, y, w, h = face[:4]
    x0, y0, x1, y1 = max(0, x), max(0, y), min(W, x + w), min(H, y + h)
    if x1 - x0 < 2 or y1 - y0 < 2:
        return None
    t = temp[y0:y1, x0:x1].astype(np.float32)
    v = valid[y0:y1, x0:x1]
    if not v.any():
        return None
    sm = cv2.blur(t, (3, 3))
    sm[~v] = -1e9
    iy, ix = np.unravel_index(int(np.argmax(sm)), sm.shape)
    ya, yb, xa, xb = max(0, iy - 1), min(t.shape[0], iy + 2), max(0, ix - 1), min(t.shape[1], ix + 2)
    nb = t[ya:yb, xa:xb][v[ya:yb, xa:xb]]
    # wartość = średnia z okna 3x3 wokół punktu: mniej szumu i mniej „schodków” palety 8-bit
    val = float(nb.mean())
    saturated = sat_level is not None and float(nb.max()) >= sat_level - 0.05
    return val, int(x0 + ix), int(y0 + iy), saturated


# ----------------------------------------------------------------------------
# Analiza pojedynczej pary klatek
# ----------------------------------------------------------------------------

@dataclass
class FrameResult:
    frame: int = 0
    srednia_temp_ciala: Optional[float] = None
    mediana_temp_ciala: Optional[float] = None
    pole_ciala_px: int = 0
    twarz: Optional[list] = None
    metoda_twarzy: Optional[str] = None
    czas_s: Optional[float] = None            # sekunda filmu (dla zdjęcia 0)
    twarz_max: Optional[float] = None         # najcieplejszy punkt twarzy [°C]
    twarz_max_xy: Optional[list] = None       # jego położenie na mapie temperatur
    twarz_max_poza_skala: bool = False        # punkt na górnym końcu skali (prawdziwa wartość może być wyższa)
    skala_min: Optional[float] = None         # skala użyta dla tej klatki (w filmie może się zmieniać)
    skala_max: Optional[float] = None
    pewnosc_twarzy: Optional[float] = None    # pewność YOLO (0–1); None = Haar/śledzenie/sylwetka
    skala_pewna: bool = True                  # False = skala nieodczytana, przyjęta domyślna (wynik niewiarygodny)
    roznica_kolor_szary: Optional[float] = None


class Analyzer:
    def __init__(self, scale: ScaleConfig, det: DetectConfig, core_offset: float = 0.0):
        self.conv = ThermalConverter(scale)
        self.det_cfg = det
        self.faces = FaceDetector(det)
        self.core_offset = core_offset
        self.prev_face = None
        self.alignment: Optional[Alignment] = None
        self._sat_warned = False
        self.detail_is_palette = False

    def temperature_map(self, color: Optional[np.ndarray], gray: Optional[np.ndarray]):
        tc = vc = tg = None
        if color is not None:
            tc, vc = self.conv.color_to_temp(color)
        if gray is not None:
            if color is not None and gray.shape[:2] != color.shape[:2]:
                gray = cv2.resize(gray, (color.shape[1], color.shape[0]), interpolation=cv2.INTER_LINEAR)
            tg = self.conv.gray_to_temp(gray, tc, vc)
        diff = None
        if tc is not None and tg is not None:
            valid = vc.copy()
            # nakładki (tekst, celownik) zwykle są białe także w wersji szarej → piksele,
            # gdzie wersje się mocno różnią, bierzemy z szarości; reszta = średnia obu.
            d = np.abs(tc - tg)
            diff = float(np.median(d[vc])) if vc.any() else None
            t = np.where(vc, 0.5 * (tc + tg), tg)
            # pasek skali i jego okolica są nieważne w obu wersjach
            if self.conv.colorbar is not None:
                cb = self.conv.colorbar
                valid_cb = np.ones_like(vc)
                valid_cb[max(0, cb.y0 - 4):cb.y1 + 4, max(0, cb.x0 - 4):cb.x1 + 4] = False
                valid = valid_cb
            else:
                valid = np.ones_like(vc)
        elif tc is not None:
            t, valid = tc, vc
        else:
            t, valid = tg, np.ones_like(tg, bool)
        return self.conv.finalize(t), valid, diff

    detail_hint: Optional[tuple] = None  # (x0, y0, szerokość) pola termowizyjnego na zdjęciu, np. z PiP FLIR

    def analyze(self, color, gray, idx=0, temp_override: Optional[np.ndarray] = None,
                detail: Optional[np.ndarray] = None):
        if temp_override is not None:  # dane radiometryczne – temperatura znana dla każdego piksela
            t, valid, diff = temp_override.astype(np.float32), np.ones(temp_override.shape, bool), None
        else:
            t, valid, diff = self.temperature_map(color, gray)
        res = FrameResult(frame=idx, roznica_kolor_szary=diff)
        if temp_override is None:
            res.skala_min, res.skala_max = self.conv.cfg.tmin, self.conv.cfg.tmax
            if any(getattr(self.conv, "scale_auto", (False, False))) and not getattr(self.conv, "scale_ok", True):
                res.skala_pewna = False
        body = segment_body(t, valid, self.det_cfg)
        res.pole_ciala_px = int(body.sum())
        if body.any():
            res.srednia_temp_ciala = float(t[body].mean()) + self.core_offset
            res.mediana_temp_ciala = float(np.median(t[body])) + self.core_offset
        # obraz do detekcji twarzy: szary (jeśli jest) albo temperatura znormalizowana
        lo_, hi_ = self.conv.cfg.tmin, self.conv.cfg.tmax
        if lo_ is None or hi_ is None or temp_override is not None:
            lo_, hi_ = float(np.percentile(t, 1)), float(np.percentile(t, 99.5))
        tn = np.clip((t - lo_) / max(1e-6, hi_ - lo_), 0, 1)
        g8 = (tn * 255).astype(np.uint8)
        det = None
        if detail is not None:
            if self.alignment is None:
                self.alignment = estimate_alignment(t, detail, self.conv.notes, self.detail_hint)
            if self.alignment.detail_is_palette:
                dv, _ = detail_value_map(detail)
                d8 = (np.clip(dv, 0, 1) * 255).astype(np.uint8)
            else:
                d8 = detail if detail.ndim == 2 else cv2.cvtColor(detail, cv2.COLOR_BGR2GRAY)
                if d8.dtype != np.uint8:
                    d8 = cv2.normalize(d8, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
            det = (d8, self.alignment)
        faces = self.faces.detect(g8, t, body, det, color)
        if faces:
            face = faces[0]
            if self.prev_face is not None:  # przy filmie preferuj twarz blisko poprzedniej
                face = max(faces, key=lambda f: iou(f, self.prev_face) + 1e-3 * f[2] * f[3] / g8.size)
            self.prev_face = face
            res.twarz = list(face[:4])
            res.metoda_twarzy = face[4]
            res.pewnosc_twarzy = round(float(face[5]), 3) if len(face) > 5 and face[5] is not None else None
            sat = None if temp_override is not None else self.conv.cfg.tmax
            hs = face_hotspot(t, valid, face, sat)
            if hs:
                res.twarz_max = hs[0] + self.core_offset
                res.twarz_max_xy = [hs[1], hs[2]]
                res.twarz_max_poza_skala = hs[3]
                if hs[3] and not self._sat_warned:
                    self._sat_warned = True
                    self.conv.notes.append(
                        f"UWAGA: najcieplejszy punkt twarzy osiąga górny koniec skali ({self.conv.cfg.tmax:g} °C) – "
                        "rzeczywista temperatura może być wyższa. Ustaw w kamerze wyższą górną granicę skali "
                        "albo nagrywaj w trybie radiometrycznym (.seq / JPG FLIR).")
        return res, t, body


# ----------------------------------------------------------------------------
# Wizualizacja
# ----------------------------------------------------------------------------

def annotate(base_bgr: np.ndarray, res: FrameResult, body: np.ndarray,
             al: Optional[Alignment] = None, show_time: bool = False, sec_avg: Optional[dict] = None) -> np.ndarray:
    """Rysuje wyniki. Gdy podano al, base_bgr to obraz szczegółowy, a współrzędne są przeliczane."""
    out = base_bgr.copy()
    if out.dtype != np.uint8:
        out = cv2.normalize(out, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    if out.ndim == 2:
        out = cv2.cvtColor(out, cv2.COLOR_GRAY2BGR)
    lw = max(1, out.shape[1] // 400)
    if al is not None:
        fx0, fy0, fx1, fy1 = al.thermal_frame()
        if fx0 > 2 or fy0 > 2 or fx1 < out.shape[1] - 2 or fy1 < out.shape[0] - 2:
            cv2.rectangle(out, (fx0, fy0), (fx1, fy1), (200, 200, 200), lw)  # pole widzenia kamery termowizyjnej
    m = al.mask_to_detail(body) if al is not None else body
    cnts, _ = cv2.findContours(m.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(out, cnts, -1, (0, 255, 0), lw)
    tr = (lambda b: al.box_to_detail(b)) if al is not None else (lambda b: b)
    if res.twarz:
        b = tr(tuple(res.twarz))
        if b:
            x, y, w, h = b
            cv2.rectangle(out, (x, y), (x + w, y + h), (255, 255, 0), 2 * lw)
    if res.twarz_max_xy:
        pts = np.array([[res.twarz_max_xy[0] + 0.5, res.twarz_max_xy[1] + 0.5, 1.0]]).T
        q = (al.T2D @ pts)[:2, 0] if al is not None else pts[:2, 0]
        cx, cy = int(round(q[0])), int(round(q[1]))
        r = max(6, 4 * lw)
        cv2.drawMarker(out, (cx, cy), (255, 0, 255), cv2.MARKER_CROSS, 3 * r, 2 * lw)
        cv2.circle(out, (cx, cy), r, (255, 0, 255), lw)
    lines = []
    if res.czas_s is not None and show_time:
        lines.append(f"Czas: {res.czas_s:.1f} s")
    if sec_avg is not None:
        # film: wartości = średnia ze wszystkich klatek danej sekundy (zmieniają się co sekundę)
        sg = sec_avg.get("sekunda", 0)
        ge = lambda b: ">= " if b else ""  # noqa: E731
        if sec_avg.get("tryb") == "pewna":
            kp = sec_avg.get("klatka_pomiaru")
            pm = sec_avg.get("pewnosc_max")
            info = (f"pomiar z kl. {kp}, pewnosc {sec_avg['pewnosc_twarzy']:.2f}" if kp is not None
                    else ("brak pewnej twarzy" if pm is None else f"brak pewnej twarzy, maks. pewnosc {pm:.2f}"))
            lines[-1:] = [f"Czas: {res.czas_s:.1f} s  ({info})"] if lines else []
        else:
            lines[-1:] = [f"Czas: {res.czas_s:.1f} s  (srednie z sekundy {sg}-{sg + 1} s, {sec_avg['klatek']} kl.)"] if lines else []
        if sec_avg.get("srednia_temp_ciala") is not None:
            lines.append(f"Cialo (sr.): {sec_avg['srednia_temp_ciala']:.1f} C")
        if sec_avg.get("najcieplejszy_punkt_twarzy") is not None:
            lines.append(f"Najcieplejszy punkt twarzy: {ge(sec_avg.get('twarz_max_poza_skala'))}"
                         f"{sec_avg['najcieplejszy_punkt_twarzy']:.1f} C"
                         + (" (koniec skali)" if sec_avg.get("twarz_max_poza_skala") else ""))
        if sec_avg.get("najcieplejszy_punkt_twarzy") is None:
            lines.append("Nie znaleziono twarzy")
    elif res.srednia_temp_ciala is not None:
        lines.append(f"Cialo (sr.): {res.srednia_temp_ciala:.1f} C")
    if sec_avg is None and res.twarz_max is not None:
        lines.append(f"Najcieplejszy punkt twarzy: {'>= ' if res.twarz_max_poza_skala else ''}{res.twarz_max:.1f} C"
                     + (" (koniec skali)" if res.twarz_max_poza_skala else ""))
    elif sec_avg is None and res.twarz is None:
        lines.append("Nie znaleziono twarzy")
    # wyniki w pasku pod obrazem, żeby nie zasłaniać napisów kamery
    s = max(0.45, out.shape[1] / 900)
    lh = int(26 * s * 1.3)
    n_lines = max(len(lines), 5 if show_time else 0)  # w filmie stała wysokość paska (stały rozmiar klatki)
    band = np.zeros((lh * n_lines + 10, out.shape[1], 3), np.uint8)
    for i, txt in enumerate(lines):
        cv2.putText(band, txt, (8, lh * (i + 1)), cv2.FONT_HERSHEY_SIMPLEX, s, (255, 255, 255), 1, cv2.LINE_AA)
    return np.vstack([out, band])


# ----------------------------------------------------------------------------
# Wejście / wyjście
# ----------------------------------------------------------------------------

def is_video(path: str) -> bool:
    return os.path.splitext(path)[1].lower() in VIDEO_EXT


def read_image(path: str) -> np.ndarray:
    data = np.fromfile(path, dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise SystemExit(f"Nie mogę wczytać obrazu: {path}")
    if img.ndim == 3 and img.shape[2] == 4:
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)
    return img


def frames(path: Optional[str], step: int = 1) -> Iterator[Optional[np.ndarray]]:
    if path is None:
        while True:
            yield None
    if not is_video(path):
        yield read_image(path)
        return
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise SystemExit(f"Nie mogę otworzyć filmu: {path}")
    i = 0
    while True:
        ok, f = cap.read()
        if not ok:
            break
        if i % step == 0:
            yield f
        i += 1
    cap.release()


def split_combined(img: np.ndarray, mode: str):
    """Jeden plik z dwiema wersjami obok siebie. Zwraca (kolor, szary) – rozpoznaje,
    która połowa jest kolorowa (większe nasycenie)."""
    h, w = img.shape[:2]
    if mode == "h":
        a, b = img[:, : w // 2], img[:, w // 2: w // 2 * 2]
    else:
        a, b = img[: h // 2], img[h // 2: h // 2 * 2]
    if img.ndim == 2:
        return None, a
    sa = cv2.cvtColor(a, cv2.COLOR_BGR2HSV)[..., 1].mean()
    sb = cv2.cvtColor(b, cv2.COLOR_BGR2HSV)[..., 1].mean()
    return (a, b) if sa >= sb else (b, a)


def is_colorful(img: np.ndarray) -> bool:
    return img.ndim == 3 and cv2.cvtColor(img, cv2.COLOR_BGR2HSV)[..., 1].mean() >= 25


def split_by_resolution(c: np.ndarray, g: np.ndarray):
    """Dwa obrazy tej samej sceny. Jeśli mają podobny rozmiar – łączymy je jak dotąd.
    Jeśli jeden jest wyraźnie większy (np. 2048x1536 przy 320x240), temperatura jest liczona
    z mniejszego (oryginalne piksele detektora), a większy służy do wykrywania twarzy i podglądu."""
    if c is None or g is None:
        return c, g, None, None
    ac, ag = c.shape[0] * c.shape[1], g.shape[0] * g.shape[1]
    if max(ac, ag) < 1.5 * min(ac, ag):
        return c, g, None, None
    small, big = (c, g) if ac < ag else (g, c)
    if is_colorful(small):
        return small, None, None, big
    sg = small if small.ndim == 2 else cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
    return None, sg, None, big


def video_fps(path: Optional[str]) -> float:
    if path and is_video(path):
        cap = cv2.VideoCapture(path)
        f = cap.get(cv2.CAP_PROP_FPS) or 25.0
        cap.release()
        return f
    return 25.0


def prime_video_scale(an: "Analyzer", path: str, combined: Optional[str] = None) -> Optional[int]:
    """Przed analizą filmu w palecie kolorów szuka klatki, w której pasek skali i liczby przy nim są
    dobrze widoczne (pierwsza klatka bywa nieczytelna, np. gdy jasna scena dotyka paska). Z tej klatki
    bierzemy paletę i położenie paska; liczby i tak są potem czytane w każdej klatce. Zwraca numer klatki."""
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        return None
    n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    idx = list(range(0, min(n, int(3 * fps)), 5)) if n > 0 else list(range(0, 90, 5))
    if n > 0:
        idx += [int(x) for x in np.linspace(0, n - 1, 16)]
    seen = set()
    try:
        for i in idx:
            if i in seen:
                continue
            seen.add(i)
            cap.set(cv2.CAP_PROP_POS_FRAMES, i)
            ok, f = cap.read()
            if not ok:
                continue
            c = split_combined(f, combined)[0] if combined else f
            if c is None or c.ndim != 3:
                return None
            bar = detect_colorbar(c, an.conv.cfg.bar_hot_end)
            res = scale_ocr.read_scale(c, bar) if bar is not None else None
            if res and _plausible_scale(res[0], res[1]):
                an.conv.init_color(c)
                if i > 0:
                    an.conv.notes.append(f"Pasek skali i paletę ustalono na podstawie klatki {i} "
                                         f"({i / fps:.1f} s) – w początkowych klatkach były nieczytelne.")
                return i
    finally:
        cap.release()
    return None


def _plural_razy(n: int) -> str:
    return f"{n} raz" if n == 1 else f"{n} razy"


def per_second(results: list[FrameResult], mode: str = "pewna", min_conf: float = 0.6) -> list[dict]:
    """Wyniki filmu sekunda po sekundzie.
    mode="pewna": JEDEN pomiar na sekundę – z klatki, w której YOLO rozpoznało twarz z największą pewnością
                  (co najmniej min_conf); gdy takiej klatki nie ma, sekunda zostaje bez wyniku.
    mode="srednia": średnia ze wszystkich klatek sekundy, w których znaleziono twarz."""
    groups: dict[int, list[FrameResult]] = {}
    sure = [r for r in results if r.skala_pewna]
    if sure:  # klatki z domyślną skalą (zanim udało się ją odczytać) nie wchodzą do średnich
        results = sure
    for r in results:
        if r.czas_s is not None:
            groups.setdefault(int(r.czas_s), []).append(r)
    out = []
    for sec in sorted(groups):
        rs = groups[sec]
        ho = [r.twarz_max for r in rs if r.twarz_max is not None]
        bo = [r.srednia_temp_ciala for r in rs if r.srednia_temp_ciala is not None]
        me = [r.metoda_twarzy for r in rs if r.metoda_twarzy]
        best = None
        if mode == "pewna":
            sure_f = [r for r in rs if r.twarz_max is not None and r.pewnosc_twarzy is not None
                      and r.pewnosc_twarzy >= min_conf]
            best = max(sure_f, key=lambda r: r.pewnosc_twarzy) if sure_f else None
            ho = [best.twarz_max] if best else []
        out.append({
            "sekunda": sec,
            "tryb": mode,
            "klatka_pomiaru": best.frame if best else None,
            "czas_pomiaru_s": best.czas_s if best else None,
            "pewnosc_twarzy": best.pewnosc_twarzy if best else None,
            "klatek": len(rs),
            "klatek_z_twarza": sum(1 for r in rs if r.twarz),
            "najcieplejszy_punkt_twarzy": float(np.mean(ho)) if ho else None,
            "najcieplejszy_punkt_twarzy_max": float(max(ho)) if ho else None,
            "srednia_temp_ciala": float(np.mean(bo)) if bo else None,
            "twarz_max_poza_skala": (best.twarz_max_poza_skala if best else False) if mode == "pewna" else
                                    any(r.twarz_max_poza_skala for r in rs if r.twarz_max is not None),
            "klatek_pewnych": sum(1 for r in rs if r.pewnosc_twarzy is not None and r.pewnosc_twarzy >= min_conf),
            # najwyższa pewność YOLO twarzy w tej sekundzie, także poniżej progu (None = YOLO nie znalazło twarzy)
            "pewnosc_max": max((r.pewnosc_twarzy for r in rs if r.pewnosc_twarzy is not None), default=None),
            "metoda_twarzy": (best.metoda_twarzy if best else None) if mode == "pewna" else
                             (max(set(me), key=me.count) if me else None),
        })
    return out


def summarize(results: list[FrameResult]) -> dict:
    n_all = len(results)
    results = [r for r in results if r.skala_pewna] or results
    body = [r.srednia_temp_ciala for r in results if r.srednia_temp_ciala is not None]
    out = {
        "klatek": n_all,
        "klatek_z_twarza": sum(1 for r in results if r.twarz),
        "srednia_temp_ciala": float(np.mean(body)) if body else None,
    }
    hot = [r for r in results if r.twarz_max is not None]
    if hot:
        top = max(hot, key=lambda r: r.twarz_max)
        out["najcieplejszy_punkt_twarzy"] = float(np.mean([r.twarz_max for r in hot])) if len(hot) > 1 else top.twarz_max
        out["najcieplejszy_punkt_twarzy_poza_skala"] = any(r.twarz_max_poza_skala for r in hot)
        if len(hot) > 1:
            out["najcieplejszy_punkt_twarzy_odchylenie"] = float(np.std([r.twarz_max for r in hot]))
        out["najcieplejszy_punkt_twarzy_max"] = top.twarz_max
        out["najcieplejszy_punkt_twarzy_czas_s"] = top.czas_s
    return out


def main(argv=None, progress=None):
    """progress(n_gotowych, n_wszystkich_lub_None) – opcjonalnie, np. dla paska postępu w oknie."""
    p = argparse.ArgumentParser(description="Analiza temperatury ciała i najcieplejszego punktu twarzy z obrazu termowizyjnego "
                                            "(wersja kolorowa + czarno-biała).")
    p.add_argument("--color", help="obraz/film w palecie kolorów")
    p.add_argument("--gray", help="obraz/film czarno-biały (ta sama scena)")
    p.add_argument("--combined", help="jeden obraz/film z obiema wersjami obok siebie")
    p.add_argument("--split", choices=["h", "v"], default="h", help="podział --combined: h=lewo/prawo, v=góra/dół")
    p.add_argument("--tmin", type=float, help="temperatura najzimniejszego koloru skali [°C] (domyślnie: odczyt z obrazu)")
    p.add_argument("--tmax", type=float, help="temperatura najgorętszego koloru skali [°C] (domyślnie: odczyt z obrazu)")
    p.add_argument("--yolo", help="model YOLO do twarzy (.onnx); domyślnie yolov8n-face.onnx obok programu, jeśli jest")
    p.add_argument("--no-yolo", action="store_true", help="nie używaj YOLO (tylko Haar + sylwetka)")
    p.add_argument("--yolo-prosty", action="store_true",
                   help="YOLO tylko na obrazie szarym, bez wariantów termowizyjnych i śledzenia (jak w wersji 0.7)")
    p.add_argument("--palette", default="auto", help="auto | bar | iron | rainbow | jet | inferno | hot | turbo | gray")
    p.add_argument("--bar-hot-end", default="auto", choices=["auto", "top", "bottom", "left", "right"])
    p.add_argument("--gray-invert", default="auto", choices=["auto", "yes", "no"])
    p.add_argument("--gray-gain", type=float, help="dane radiometryczne: T = gain*wartość + offset")
    p.add_argument("--gray-offset", type=float, default=0.0)
    p.add_argument("--emissivity", type=float, help="emisyjność (skóra ≈ 0.98). Pliki FLIR: domyślnie wartość z kamery; "
                                                    "inne obrazy: domyślnie bez korekcji")
    p.add_argument("--reflected-temp", type=float, help="temperatura odbita [°C] (FLIR: domyślnie z kamery, inaczej 22)")
    p.add_argument("--distance", type=float, help="FLIR: odległość od osoby [m] (domyślnie z kamery)")
    p.add_argument("--humidity", type=float, help="FLIR: wilgotność względna [%%] (domyślnie z kamery)")
    p.add_argument("--atm-temp", type=float, help="FLIR: temperatura powietrza [°C] (domyślnie z kamery)")
    p.add_argument("--body-tmin", type=float, default=28.0, help="minimalna temperatura uznawana za ciało [°C]")
    p.add_argument("--body-tmax", type=float, default=42.0)
    p.add_argument("--core-offset", type=float, default=0.0, help="stała dodawana do wyniku (np. 1.0 by szacować temp. wewnętrzną)")
    p.add_argument("--forehead-metric", help=argparse.SUPPRESS)  # usunięte (zgodność ze starszym oknem)
    p.add_argument("--yunet", help="ścieżka do modelu face_detection_yunet_*.onnx (opcjonalnie, lepsza detekcja twarzy)")
    p.add_argument("--step", type=int, default=1, help="film: analizuj co N-tą klatkę")
    p.add_argument("--tryb-sekundy", choices=["pewna", "srednia"], default="pewna",
                   help="film: pewna = jeden pomiar na sekundę z klatki z najpewniejszą twarzą (YOLO ≥ --pewnosc); "
                        "srednia = średnia ze wszystkich klatek sekundy z twarzą")
    p.add_argument("--pewnosc", type=float, default=0.6, help="minimalna pewność YOLO dla trybu pewna (0–1)")
    p.add_argument("--pomin", type=int, default=30,
                   help="film, tryb pewna: po każdym pomiarze (pewna twarz) pomiń tyle kolejnych klatek bez analizy; "
                        "0 = analizuj każdą klatkę")
    p.add_argument("--pomin-bez-twarzy", type=int, default=3,
                   help="film, tryb pewna: gdy w klatce nie ma pewnej twarzy, pomiń tyle kolejnych klatek bez analizy; "
                        "0 = sprawdzaj każdą klatkę")
    p.add_argument("--out", default="wynik", help="katalog wyjściowy")
    a = p.parse_args(argv)

    if not (a.color or a.gray or a.combined):
        p.error("podaj --color i/lub --gray albo --combined")

    scale = ScaleConfig(a.tmin, a.tmax, a.palette, a.bar_hot_end, a.gray_invert, a.gray_gain,
                        a.gray_offset, a.emissivity if a.emissivity is not None else 1.0,
                        a.reflected_temp if a.reflected_temp is not None else 22.0)
    yolo_path = None if a.no_yolo else (a.yolo or resource_path("yolov8n-face.onnx"))
    det = DetectConfig(a.body_tmin, a.body_tmax, yunet_model=a.yunet, yolo_model=yolo_path,
                       thermal_yolo=not a.yolo_prosty)
    _src = a.combined or a.color or a.gray
    video_input = bool(_src) and (is_video(_src) or _src.lower().endswith(".seq"))
    if video_input and yolo_path and not a.yolo_prosty:
        # film z YOLO: w klatkach bez twarzy (tył głowy, profil, ręka przed kamerą) „głowa z sylwetki”
        # wskazywała włosy albo ubranie – lepiej zostawić klatkę bez wyniku; średnie z sekundy biorą
        # tylko klatki z twarzą
        det.body_fallback = False
    an = Analyzer(scale, det, a.core_offset)
    if an.faces.yolo_note:
        an.conv.notes.append(an.faces.yolo_note)
    elif not a.no_yolo:
        an.conv.notes.append("Brak modelu YOLO (yolov8n-face.onnx) – twarz szukana metodą Haar i z sylwetki.")
    os.makedirs(a.out, exist_ok=True)

    src_main = a.combined or a.color or a.gray
    flir_src = next((x for x in (a.color, a.gray, a.combined) if x and flir.is_flir_radiometric(x)), None)
    flir_meta = None
    if flir_src:
        src_main = flir_src
        video = flir_src.lower().endswith(".seq")
        hum = None if a.humidity is None else a.humidity / 100.0

        other = next((x for x in (a.color, a.gray) if x and x != flir_src), None)
        other_frames = frames(other, a.step) if other else frames(None)
        emb_vis, pip = flir.read_flir_visual(flir_src) if not video else (None, None)
        if other is None and emb_vis is not None:
            # zdjęcie wizyjne zapisane przez kamerę w tym samym pliku – szersze pole widzenia,
            # wyższa rozdzielczość; służy do szukania twarzy
            other_frames = itertools.repeat(emb_vis)
            an.conv.notes.append(f"Użyto zdjęcia wizyjnego zapisanego w pliku FLIR ({emb_vis.shape[1]}x{emb_vis.shape[0]}) "
                                 "do wykrywania twarzy.")

        def flir_frames():
            nonlocal flir_meta
            it = flir.iter_seq(flir_src, a.step) if video else [flir.read_flir_file(flir_src)]
            for item in it:
                if item is None:
                    raise SystemExit(f"Plik {flir_src} nie zawiera danych radiometrycznych FLIR.")
                raw, prm = item
                if flir_meta is None:
                    flir_meta = prm
                    ds = flir.display_scale(prm)
                    if ds and (a.tmin is None or a.tmax is None):
                        a.tmin = round(ds[0], 1) if a.tmin is None else a.tmin
                        a.tmax = round(ds[1], 1) if a.tmax is None else a.tmax
                        an.conv.notes.append(f"Skala zdjęcia z danych kamery: {a.tmin:g}…{a.tmax:g} °C.")
                    a.tmin = 20.0 if a.tmin is None else a.tmin
                    a.tmax = 40.0 if a.tmax is None else a.tmax
                    scale.tmin, scale.tmax = a.tmin, a.tmax
                    an.conv.notes.append(
                        f"Dane radiometryczne FLIR ({prm.camera_model}, nr {prm.serial}): temperatura liczona z surowych "
                        f"danych detektora, bez skali kolorów. Emisyjność {a.emissivity or prm.emissivity:.2f}, "
                        f"odległość {a.distance if a.distance is not None else prm.object_distance:.1f} m, "
                        f"temp. odbita {a.reflected_temp if a.reflected_temp is not None else prm.reflected_temp:.1f} °C.")
                t = flir.raw_to_celsius(raw, prm, a.emissivity, a.distance, a.reflected_temp, a.atm_temp, hum)
                det_img = next(other_frames)
                if (an.detail_hint is None and pip and emb_vis is not None and det_img is not None
                        and det_img.shape[:2] == emb_vis.shape[:2]):
                    Hd, Wd = det_img.shape[:2]
                    w_ = Wd / pip["real2ir"]
                    h_ = w_ * t.shape[0] / t.shape[1]
                    an.detail_hint = (Wd / 2 + pip["offset_x"] - w_ / 2, Hd / 2 + pip["offset_y"] - h_ / 2, w_)
                yield None, None, t, det_img

        pairs = flir_frames()
    else:
        video = is_video(src_main)
        if a.combined:
            pairs = ((*split_combined(f, a.split), None, None) for f in frames(a.combined, a.step))
        else:
            pairs = (split_by_resolution(c, g) for c, g in zip(frames(a.color, a.step), frames(a.gray, a.step))) if (a.color and a.gray) else \
                ((f, None, None, None) for f in frames(a.color, a.step)) if a.color else ((None, f, None, None) for f in frames(a.gray, a.step))

    writer = None
    results: list[FrameResult] = []
    iron = builtin_palettes()["iron"][:, ::-1]
    src_fps = 30.0 if flir_src else video_fps(src_main)  # .seq: FLIR zapisuje zwykle 30 kl./s
    total = None
    if video and not flir_src:
        cap = cv2.VideoCapture(src_main)
        n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        cap.release()
        total = (n + a.step - 1) // a.step if n > 0 else None
    if video and not flir_src and (a.tmin is None or a.tmax is None) \
            and (a.combined or (a.color and not a.gray)):
        prime_video_scale(an, a.combined or a.color, a.split if a.combined else None)
    pending: list = []
    pending_sec = None
    skip_n = max(0, a.pomin) if (video and a.tryb_sekundy == "pewna") else 0
    skip_nf = max(0, a.pomin_bez_twarzy) if (video and a.tryb_sekundy == "pewna") else 0
    skip_left = 0        # ile klatek jeszcze pominąć po ostatnim pomiarze
    skipped = 0
    last_vis = None      # (kształt mapy temperatur, powiększenie, al_vis) z ostatniej analizowanej klatki

    def flush_second():
        nonlocal writer
        agg = per_second([r for _, r, _, _, sk in pending if not sk] or [pending[0][1]], a.tryb_sekundy, a.pewnosc)[0]
        for b_, r_, body_, al_, _ in pending:
            vis = annotate(b_, r_, body_, al_, show_time=True, sec_avg=agg)
            if writer is None:
                writer = cv2.VideoWriter(os.path.join(a.out, "adnotacje.mp4"),
                                         cv2.VideoWriter_fourcc(*"mp4v"), src_fps / a.step, (vis.shape[1], vis.shape[0]))
            writer.write(vis)
        pending.clear()

    try:
        for i, (c, g, tov, det) in enumerate(pairs):
            if skip_left > 0 and last_vis is not None:
                # klatka tuż po pomiarze: bez analizy (oszczędność czasu), do filmu wynikowego trafia sam obraz
                skip_left -= 1
                skipped += 1
                (th, tw), k_, al_ = last_vis
                base = c if c is not None else (g if g.dtype == np.uint8 else
                                                cv2.normalize(g, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8))
                if base.ndim == 2:
                    base = cv2.cvtColor(base, cv2.COLOR_GRAY2BGR)
                base = cv2.resize(base, (int(round(tw * k_)), int(round(th * k_))), interpolation=cv2.INTER_CUBIC)
                res = FrameResult(frame=i * a.step, czas_s=round(i * a.step / src_fps, 3))
                sec = int(res.czas_s)
                if pending and pending_sec != sec:
                    flush_second()
                pending_sec = sec
                pending.append((base, res, np.zeros((th, tw), bool), al_, True))
                if progress is not None:
                    progress(i + 1, total)
                continue
            res, t, body = an.analyze(c, g, i * a.step, tov, det)
            if video:
                res.czas_s = round(i * a.step / src_fps, 3)
            results.append(res)
            if progress is not None:
                progress(i + 1, total)
            if tov is not None:  # dane radiometryczne: podgląd = obraz z kamery albo paleta iron
                vis_jpg = read_image(flir_src) if (flir_src and not video and flir_src.lower().endswith((".jpg", ".jpeg"))) else None
                if vis_jpg is not None and vis_jpg.shape[:2] == t.shape[:2]:
                    base = vis_jpg
                else:
                    vi = np.clip((t - a.tmin) / max(1e-6, a.tmax - a.tmin), 0, 1)
                    base = iron[(vi * 255).astype(np.int32)].astype(np.uint8)
            else:
                base = c if c is not None else (g if g.dtype == np.uint8 else cv2.normalize(g, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8))
            # podgląd zawsze na obrazie termowizyjnym; mały termogram (np. 320x240) powiększamy, żeby
            # napisy i ramki były czytelne. Zdjęcie wizyjne służy tylko do szukania twarzy.
            if base.shape[:2] != t.shape[:2]:
                base = cv2.resize(base, (t.shape[1], t.shape[0]), interpolation=cv2.INTER_AREA)
            k = max(1.0, 960.0 / base.shape[1])
            al_vis = None
            if k > 1.0:
                base = cv2.resize(base, None, fx=k, fy=k, interpolation=cv2.INTER_CUBIC)
                al_vis = Alignment(np.diag([k, k, 1.0]), t.shape, base.shape, 0, "")
            if video:
                last_vis = (t.shape[:2], k, al_vis)
                measured = (res.twarz_max is not None and res.pewnosc_twarzy is not None
                            and res.pewnosc_twarzy >= a.pewnosc)
                if not measured and skip_nf:
                    skip_left = skip_nf  # brak pewnej twarzy: kolejne klatki pewnie też bez twarzy
                elif measured and skip_n:
                    skip_left = skip_n
                    an.faces._last_yolo = None  # po przerwie śledzenie twarzy zaczyna od nowa
                # wartości w filmie wynikowym zmieniają się co sekundę: klatki jednej sekundy czekają,
                # aż będzie znana średnia z całej sekundy
                sec = int(res.czas_s or 0)
                if pending and pending_sec != sec:
                    flush_second()
                pending_sec = sec
                pending.append((base, res, body, al_vis, False))
            else:
                vis = annotate(base, res, body, al_vis)
                cv2.imwrite(os.path.join(a.out, "adnotacje.png"), vis)
                tn = cv2.normalize(t, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
                cv2.imwrite(os.path.join(a.out, "mapa_temperatury.png"), cv2.applyColorMap(tn, cv2.COLORMAP_INFERNO))
                np.save(os.path.join(a.out, "mapa_temperatury.npy"), t)
        if pending:
            flush_second()
    finally:
        # bez release() plik .mp4 jest nieczytelny („moov atom not found”)
        if writer is not None:
            writer.release()
    if not results:
        raise SystemExit("Brak klatek do analizy.")

    if getattr(an.conv, "scale_changes", 0):
        hist = getattr(an.conv, "scale_history", [])
        rng = ""
        if hist:
            los, his = [h[0] for h in hist], [h[1] for h in hist]
            rng = f" Górna granica: {min(his):g}…{max(his):g} °C, dolna: {min(los):g}…{max(los):g} °C."
        an.conv.notes.append(f"Skala kamery zmieniała się w trakcie filmu ({_plural_razy(an.conv.scale_changes)}) – liczby "
                             "przy pasku są czytane w każdej klatce, a temperatury liczone z aktualnej skali." + rng)
    if getattr(an.conv, "scale_read_failures", 0):
        an.conv.notes.append(f"W {an.conv.scale_read_failures} klatkach liczb przy pasku nie dało się odczytać – "
                             "użyto ostatniej odczytanej skali.")
    summary = summarize(results)
    report = {
        "podsumowanie": summary,
        "uwagi": an.conv.notes,
        "zalozenia": {
            "tmin": scale.tmin, "tmax": scale.tmax, "emisyjnosc": a.emissivity,
            "flir_kamera": flir_meta.as_dict() if flir_meta else None,
            "korekta_temp_wewnetrznej": a.core_offset,
            "zakres_ciala": [a.body_tmin, a.body_tmax],
        },
        "klatki": [asdict(r) for r in results],
    }
    seconds = per_second(results, a.tryb_sekundy, a.pewnosc) if video else []
    if seconds:  # sekundy, w których wszystkie klatki pominięto, też dostają (pusty) wiersz
        have = {d["sekunda"] for d in seconds}
        for s_ in range(seconds[0]["sekunda"], seconds[-1]["sekunda"]):
            if s_ not in have:
                e_ = per_second([FrameResult(frame=-1, czas_s=float(s_))], a.tryb_sekundy, a.pewnosc)[0]
                e_["klatek"] = 0
                seconds.append(e_)
        seconds.sort(key=lambda d: d["sekunda"])
    if video:
        # podsumowanie filmu z wyników sekund (w trybie „pewna”: tylko sekundy z pewną twarzą)
        sv = [d for d in seconds if d["najcieplejszy_punkt_twarzy"] is not None]
        for k in ("najcieplejszy_punkt_twarzy", "najcieplejszy_punkt_twarzy_max", "najcieplejszy_punkt_twarzy_czas_s",
                  "najcieplejszy_punkt_twarzy_odchylenie", "najcieplejszy_punkt_twarzy_poza_skala"):
            summary.pop(k, None)
        summary["tryb_sekundy"] = a.tryb_sekundy
        summary["pewnosc_min"] = a.pewnosc if a.tryb_sekundy == "pewna" else None
        summary["sekund_z_wynikiem"] = len(sv)
        summary["sekund"] = len(seconds)
        summary["klatek_pominietych"] = skipped
        summary["pomin_po_pomiarze"] = skip_n
        summary["pomin_bez_twarzy"] = skip_nf
        if sv:
            top = max(sv, key=lambda d: d["najcieplejszy_punkt_twarzy_max"])
            summary["najcieplejszy_punkt_twarzy"] = float(np.mean([d["najcieplejszy_punkt_twarzy"] for d in sv]))
            summary["najcieplejszy_punkt_twarzy_max"] = top["najcieplejszy_punkt_twarzy_max"]
            summary["najcieplejszy_punkt_twarzy_czas_s"] = (top["czas_pomiaru_s"] if top["czas_pomiaru_s"] is not None
                                                           else float(top["sekunda"]))
            summary["najcieplejszy_punkt_twarzy_poza_skala"] = any(d["twarz_max_poza_skala"] for d in sv)
            if len(sv) > 1:
                summary["najcieplejszy_punkt_twarzy_odchylenie"] = float(np.std([d["najcieplejszy_punkt_twarzy"] for d in sv]))
        report["podsumowanie"] = summary
    if video:
        report["sekundy"] = seconds
    with open(os.path.join(a.out, "raport.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    if video:
        with open(os.path.join(a.out, "klatki.csv"), "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["klatka", "czas_s", "srednia_temp_ciala", "najcieplejszy_punkt_twarzy",
                        "metoda_twarzy", "pewnosc_twarzy", "roznica_kolor_szary", "skala_min", "skala_max", "koniec_skali"])
            for r in results:
                w.writerow([r.frame, _fmt(r.czas_s), _fmt(r.srednia_temp_ciala), _fmt(r.twarz_max),
                            r.metoda_twarzy or "", _fmt(r.pewnosc_twarzy), _fmt(r.roznica_kolor_szary),
                            _fmt(r.skala_min), _fmt(r.skala_max),
                            "tak" if r.twarz_max_poza_skala else ""])
        with open(os.path.join(a.out, "sekundy.csv"), "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["sekunda", "klatek", "klatek_z_twarza", "klatek_z_pewna_twarza", "najcieplejszy_punkt_twarzy",
                        "najcieplejszy_punkt_max", "klatka_pomiaru", "pewnosc_twarzy", "srednia_temp_ciala",
                        "koniec_skali", "pewnosc_max"])
            for d in seconds:
                w.writerow([d["sekunda"], d["klatek"], d["klatek_z_twarza"], d["klatek_pewnych"],
                            _fmt(d["najcieplejszy_punkt_twarzy"]), _fmt(d["najcieplejszy_punkt_twarzy_max"]),
                            "" if d["klatka_pomiaru"] is None else d["klatka_pomiaru"], _fmt(d["pewnosc_twarzy"]),
                            _fmt(d["srednia_temp_ciala"]),
                            "tak" if d["twarz_max_poza_skala"] else "", _fmt(d.get("pewnosc_max"))])

    print("=== WYNIK ===")
    for n in an.conv.notes:
        print("  *", n)
    st = summary
    print(f"Średnia temperatura powierzchni ciała: {_fmt(st['srednia_temp_ciala'])} °C")
    if st.get("najcieplejszy_punkt_twarzy") is not None:
        if video:
            extra = (f" (±{st['najcieplejszy_punkt_twarzy_odchylenie']:.2f} między sekundami)"
                     if "najcieplejszy_punkt_twarzy_odchylenie" in st else "")
            print(f"Najcieplejszy punkt twarzy (wyniki sekund): średnio {st['najcieplejszy_punkt_twarzy']:.2f} °C{extra}, najwyższy "
                  f"{st['najcieplejszy_punkt_twarzy_max']:.2f} °C w {st['najcieplejszy_punkt_twarzy_czas_s']:.1f} s")
        else:
            print(f"Najcieplejszy punkt twarzy: {'≥ ' if st.get('najcieplejszy_punkt_twarzy_poza_skala') else ''}"
                  f"{st['najcieplejszy_punkt_twarzy']:.2f} °C  [twarz: {results[0].metoda_twarzy}]")
    else:
        print("Nie znaleziono twarzy.")
    if video:
        if a.tryb_sekundy == "pewna" and (skip_n or skip_nf):
            print(f"Najcieplejszy punkt twarzy – pomiar z pierwszej klatki z pewną twarzą (YOLO ≥ {a.pewnosc:.2f}); "
                  f"pomijane klatki: {skip_n} po pomiarze, {skip_nf} po klatce bez pewnej twarzy; "
                  f"pominięto {skipped} z {skipped + len(results)} klatek (≥ = koniec skali kamery):")
        elif a.tryb_sekundy == "pewna":
            print(f"Najcieplejszy punkt twarzy – jeden pomiar na sekundę, z klatki z najpewniejszą twarzą "
                  f"(YOLO ≥ {a.pewnosc:.2f}; ≥ = koniec skali kamery):")
        else:
            print("Najcieplejszy punkt twarzy w kolejnych sekundach filmu – średnia ze wszystkich klatek sekundy "
                  "z twarzą (≥ = koniec skali kamery):")
        for d in seconds:
            ho = d["najcieplejszy_punkt_twarzy"]
            hs = ("≥" if d["twarz_max_poza_skala"] else "") + (_fmt(ho) if ho is not None else "–")
            if a.tryb_sekundy == "pewna":
                pm = d.get("pewnosc_max")
                src = (f"kl. {d['klatka_pomiaru']}, pewność {d['pewnosc_twarzy']:.2f}" if d["klatka_pomiaru"] is not None
                       else ("brak twarzy YOLO" if pm is None else f"brak pewnej twarzy, najwyższa pewność {pm:.2f}"))
                print(f"   {d['sekunda']:4d} s: {hs:>7} °C  ({src}; {d['klatek_pewnych']}/{d['klatek']} kl. z pewną twarzą)")
            else:
                print(f"   {d['sekunda']:4d} s: {hs:>7} °C  ({d['klatek_z_twarza']}/{d['klatek']} kl. z twarzą)")
    if results[0].roznica_kolor_szary is not None:
        print(f"Mediana różnicy kolor vs szary: {results[0].roznica_kolor_szary:.2f} °C (kontrola spójności)")
    print(f"Wyniki zapisane w: {os.path.abspath(a.out)}")
    return report


def _fmt(v):
    return "" if v is None else f"{v:.2f}"


if __name__ == "__main__":
    main()
