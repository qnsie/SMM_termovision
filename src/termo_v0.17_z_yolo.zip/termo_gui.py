#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Okno programu: nowoczesny wygląd (customtkinter), odtwarzacz filmu z wynikami,
twarz i jej najcieplejszy punkt w każdej sekundzie filmu."""
import io
import os
import sys
import threading
import traceback
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import tkinter.font as tkfont

import cv2
import numpy as np
from PIL import Image, ImageTk
import customtkinter as ctk

import termo_analyzer as ta

APP_NAME = "Analizator Termo"
VERSION = "0.17"
FILETYPES = [("Obrazy i filmy", "*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.webp *.mp4 *.avi *.mov *.mkv *.wmv *.m4v *.seq *.fff"),
             ("Wszystkie pliki", "*.*")]

# kolory
BG = "#0f1115"
PANEL = "#171a21"
CARD = "#1f232c"
BORDER = "#2a2f3a"
TEXT = "#e8eaef"
MUTED = "#8b93a5"
ACCENT = "#ff7a1a"       # pomarańcz „termo”
ACCENT_H = "#ff9447"
C_HOT = "#ff3d8b"        # najcieplejszy punkt twarzy
C_BODY = "#3ddc97"       # ciało
C_OK = "#1f9d55"         # okienko alarmu: temperatura w normie
C_ALARM = "#d62f2f"      # okienko alarmu: wysoka temperatura

FONT = "Segoe UI" if sys.platform.startswith("win") else "DejaVu Sans"


def _base_dir():
    return os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(os.path.abspath(__file__))


class _TextRedirect(io.TextIOBase):
    def __init__(self, app):
        self.app = app

    def write(self, s):
        self.app.after(0, self.app.log, s)
        return len(s)


class StatCard(ctk.CTkFrame):
    """Kafelek z dużą liczbą (np. najcieplejszy punkt twarzy)."""

    def __init__(self, master, title, color, sub=""):
        super().__init__(master, fg_color=CARD, corner_radius=14, border_width=1, border_color=BORDER)
        bar = ctk.CTkFrame(self, fg_color=color, width=5, height=10, corner_radius=2)
        bar.pack(side="left", fill="y", padx=(10, 0), pady=12)
        box = ctk.CTkFrame(self, fg_color="transparent")
        box.pack(side="left", fill="both", expand=True, padx=12, pady=8)
        self.title_lbl = ctk.CTkLabel(box, text=title, text_color=MUTED, font=(FONT, 12))
        self.title_lbl.pack(anchor="w")
        self.value = ctk.CTkLabel(box, text="–", text_color=TEXT, font=(FONT, 28, "bold"))
        self.value.pack(anchor="w")
        self.sub = ctk.CTkLabel(box, text=sub, text_color=MUTED, font=(FONT, 11))
        self.sub.pack(anchor="w")

    def set(self, value, sub=None, title=None):
        if title is not None:
            self.title_lbl.configure(text=title)
        self.value.configure(text=value)
        if sub is not None:
            self.sub.configure(text=sub)


class AlarmBanner(ctk.CTkFrame):
    """Okienko oceny: zielone „temperatura w normie” albo czerwone „wysoka temperatura”."""

    def __init__(self, master):
        super().__init__(master, fg_color=CARD, corner_radius=14, border_width=1, border_color=BORDER)
        self.head = ctk.CTkLabel(self, text="Ocena temperatury – brak wyniku", text_color=TEXT,
                                 font=(FONT, 22, "bold"))
        self.head.pack(side="left", padx=(18, 12), pady=10)
        self.sub = ctk.CTkLabel(self, text="wybierz plik i kliknij „Analizuj”", text_color=MUTED, font=(FONT, 12),
                                justify="left", anchor="w", wraplength=460)
        self.sub.pack(side="left", fill="x", expand=True, padx=(0, 14), pady=10)

    def set(self, state, head, sub):
        bg = {"ok": C_OK, "alarm": C_ALARM, "warn": ACCENT}.get(state, CARD)
        lit = state in ("ok", "alarm", "warn")
        self.configure(fg_color=bg, border_color=bg if lit else BORDER)
        self.head.configure(text=head, text_color="#ffffff" if lit else TEXT)
        self.sub.configure(text=sub, text_color="#ffffff" if lit else MUTED)


TRYB_PEWNA = "co 1 s"         # jeden pomiar na sekundę z klatki z najpewniejszą twarzą
TRYB_SREDNIA = "średnia"       # średnia ze wszystkich klatek sekundy


class Chart(tk.Canvas):
    """Wykres temperatury najcieplejszego punktu twarzy w czasie filmu, z kursorem."""

    def __init__(self, master, on_seek):
        super().__init__(master, bg=CARD, highlightthickness=0, height=150)
        self.on_seek = on_seek
        self.times, self.hot = [], []
        self.cursor = 0.0
        self.bind("<Configure>", lambda e: self.redraw())
        self.bind("<Button-1>", self._click)
        self.bind("<B1-Motion>", self._click)

    def set_data(self, times, hot):
        self.times, self.hot = times, hot
        self.redraw()

    def set_cursor(self, t):
        self.cursor = t
        self.redraw()

    def _geom(self):
        # marginesy z rozmiaru czcionki, żeby opisy osi mieściły się przy każdym skalowaniu ekranu
        f = tkfont.Font(font=(FONT, 9))
        lh = f.metrics("linespace")
        W, H = max(50, self.winfo_width()), max(50, self.winfo_height())
        return f.measure("00.0") + 14, lh + 6, W - 12, H - int(lh * 1.8)

    def _click(self, e):
        if len(self.times) < 2:
            return
        x0, _, x1, _ = self._geom()
        T = self.times[-1] or 1.0
        self.on_seek(min(max((e.x - x0) / max(1, x1 - x0), 0), 1) * T)

    def redraw(self):
        self.delete("all")
        x0, y0, x1, y1 = self._geom()
        vals = [v for v in self.hot if v is not None]
        if len(self.times) < 2 or not vals:
            self.create_text((x0 + x1) / 2, (y0 + y1) / 2, text="Wykres pojawi się po analizie filmu",
                             fill=MUTED, font=(FONT, 11))
            return
        lo, hi = min(vals) - 0.3, max(vals) + 0.3
        T = self.times[-1] or 1.0
        X = lambda t: x0 + (x1 - x0) * t / T  # noqa: E731
        Y = lambda v: y1 - (y1 - y0) * (v - lo) / max(1e-6, hi - lo)  # noqa: E731
        for k in range(5):  # siatka
            v = lo + (hi - lo) * k / 4
            self.create_line(x0, Y(v), x1, Y(v), fill=BORDER)
            self.create_text(x0 - 6, Y(v), text=f"{v:.1f}", fill=MUTED, anchor="e", font=(FONT, 9))
        step = max(1, int(T / 10) or 1)
        for s in range(0, int(T) + 1, step):
            self.create_text(X(s), y1 + 4, text=f"{s} s", fill=MUTED, font=(FONT, 9), anchor="n")
        for series, col in ((self.hot, C_HOT),):
            segs, seg = [], []
            for t, v in zip(self.times, series):
                if v is None:
                    if len(seg) >= 4:
                        segs.append(seg)
                    seg = []
                else:
                    seg += [X(t), Y(v)]
            if len(seg) >= 4:
                segs.append(seg)
            for sg in segs:
                self.create_line(*sg, fill=col, width=2)
            if len(series) <= 120:  # wynik co sekundę: kropka przy każdym pomiarze (widać też pojedyncze)
                for t, v in zip(self.times, series):
                    if v is not None:
                        self.create_oval(X(t) - 3, Y(v) - 3, X(t) + 3, Y(v) + 3, fill=col, outline="")
        cx = X(min(self.cursor, T))
        self.create_line(cx, y0, cx, y1, fill=TEXT, dash=(3, 3))
        self.create_text(x1, 2, text="━ najcieplejszy punkt twarzy (wynik sekundy)", fill=C_HOT, anchor="ne",
                         font=(FONT, 9))


class App(ctk.CTk):
    def __init__(self):
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("dark-blue")
        super().__init__(fg_color=BG)
        self.title(f"{APP_NAME} {VERSION} – temperatura ciała z kamery termowizyjnej")
        self.minsize(900, 600)
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"{min(1360, int(sw * 0.9))}x{min(880, int(sh * 0.85))}+20+20")
        if sys.platform.startswith("win"):
            self.after(50, lambda: self.state("zoomed"))  # na Windows okno od razu na cały ekran
        self.vars = {
            "color": tk.StringVar(), "gray": tk.StringVar(), "combined": tk.StringVar(),
            "split": tk.StringVar(value="h"),
            "tmin": tk.StringVar(value=""), "tmax": tk.StringVar(value=""),
            "palette": tk.StringVar(value="auto"), "gray_invert": tk.StringVar(value="auto"),
            "emissivity": tk.StringVar(value=""), "distance": tk.StringVar(value=""), "core_offset": tk.StringVar(value="0"),
            "body_tmin": tk.StringVar(value="28"), "step": tk.StringVar(value="1"),
            "tryb": tk.StringVar(value=TRYB_PEWNA), "pewnosc": tk.StringVar(value="0.6"),
            "pomin": tk.StringVar(value="30"),
            "trzymaj": tk.StringVar(value="5"), "pomin_bt": tk.StringVar(value="3"),
            "alarm_prog": tk.StringVar(value="37.5"), "alarm_ile": tk.StringVar(value="2"),
            "out": tk.StringVar(value=os.path.join(os.path.expanduser("~"), "Documents", "termo_wyniki")),
        }
        # odtwarzacz
        self.cap = None
        self.n_frames = 0
        self.fps = 25.0
        self.playing = False
        self.cur = 0
        self.frames_data = []
        self.summary = {}
        self.seconds = {}
        self._photo = None
        self._still = None
        self._seeking = False
        self._build()

    # ------------------------------------------------------------------ układ
    def _build(self):
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        sidebar = ctk.CTkFrame(self, width=360, fg_color=PANEL, corner_radius=0)
        sidebar.grid(row=0, column=0, sticky="nsw")
        bottom = ctk.CTkFrame(sidebar, fg_color=PANEL, corner_radius=0)  # zawsze widoczny przycisk „Analizuj”
        bottom.pack(side="bottom", fill="x")
        side = ctk.CTkScrollableFrame(sidebar, width=330, fg_color=PANEL, corner_radius=0)
        side.pack(side="top", fill="both", expand=True)
        main = ctk.CTkFrame(self, fg_color=BG, corner_radius=0)
        main.grid(row=0, column=1, sticky="nsew", padx=18, pady=14)

        # nagłówek
        head = ctk.CTkFrame(side, fg_color="transparent")
        head.pack(fill="x", padx=14, pady=(14, 6))
        logo = tk.Canvas(head, width=40, height=40, bg=PANEL, highlightthickness=0)
        for i, c in enumerate(("#2b1a6b", "#7a1f8c", "#d43d5a", "#ff7a1a", "#ffd23f")):
            logo.create_oval(4 + i * 3, 4 + i * 3, 36 - i * 3, 36 - i * 3, fill=c, outline="")
        logo.pack(side="left")
        tb = ctk.CTkFrame(head, fg_color="transparent")
        tb.pack(side="left", padx=10)
        ctk.CTkLabel(tb, text=APP_NAME, font=(FONT, 20, "bold"), text_color=TEXT).pack(anchor="w")
        ctk.CTkLabel(tb, text=f"wersja {VERSION} · kamera termowizyjna FLIR", font=(FONT, 11), text_color=MUTED).pack(anchor="w")

        # pliki
        files = self._section(side, "Pliki")
        self._file_row(files, "Zdjęcie FLIR (JPG) albo film z kamery", "color")
        ctk.CTkLabel(files, text="Wystarczy jeden plik – sama termowizja. Zdjęcie JPG z kamery FLIR ma w sobie "
                          "dane temperatury, a film – pasek skali, z którego program odczytuje temperatury.",
                     font=(FONT, 11), text_color=MUTED, justify="left", wraplength=270).pack(anchor="w", pady=(4, 6))

        # parametry
        par = self._section(side, "Skala i pomiar")
        grid = ctk.CTkFrame(par, fg_color="transparent")
        grid.pack(fill="x")
        grid.grid_columnconfigure(1, weight=1)
        self._param_rows(grid, [
            ("Pomiar w filmie", "tryb", [TRYB_PEWNA, TRYB_SREDNIA], None),
            ("Min. pewność twarzy", "pewnosc", None, "0–1"),
            ("Pomiń kl. po pomiarze", "pomin", None, "0 = każda"),
            ("Pomiń kl. bez twarzy", "pomin_bt", None, "0 = każda"),
            ("Pokaż ost. pomiar [s]", "trzymaj", None, "0 = nie"),
            ("Min skali [°C]", "tmin", None, "z obrazu"),
            ("Max skali [°C]", "tmax", None, "z obrazu"),
            ("Emisyjność", "emissivity", None, "z kamery"),
            ("Odległość [m]", "distance", None, "z kamery"),
        ])
        alarm = self._section(side, "Alarm temperatury")
        ga = ctk.CTkFrame(alarm, fg_color="transparent")
        ga.pack(fill="x")
        ga.grid_columnconfigure(1, weight=1)
        self._param_rows(ga, [
            ("Próg alarmu [°C]", "alarm_prog", None, None),
            ("Min. pomiarów powyżej", "alarm_ile", None, None),
        ])
        for k in ("alarm_prog", "alarm_ile"):  # zmiana progu od razu zmienia ocenę, bez ponownej analizy
            self.vars[k].trace_add("write", lambda *_: self._update_alarm())
        more = self._section(side, "Zaawansowane", collapsed=True)
        g2 = ctk.CTkFrame(more, fg_color="transparent")
        g2.pack(fill="x")
        g2.grid_columnconfigure(1, weight=1)
        self._param_rows(g2, [
            ("Paleta", "palette", ["auto", "bar", "iron", "rainbow", "jet", "inferno", "hot", "turbo", "gray"], None),
            ("Szary odwrócony", "gray_invert", ["auto", "no", "yes"], None),
            ("Korekta do temp. wewn. [°C]", "core_offset", None, "0"),
            ("Min. temp. ciała [°C]", "body_tmin", None, "28"),
            ("Film: co N-ta klatka", "step", None, "1"),
        ])

        outs = self._section(side, "Folder wyników")
        row = ctk.CTkFrame(outs, fg_color="transparent")
        row.pack(fill="x")
        ctk.CTkEntry(row, textvariable=self.vars["out"]).pack(side="left", fill="x", expand=True)
        ctk.CTkButton(row, text="…", width=34, fg_color=BORDER, hover_color="#363c4a",
                      command=self._pick_out).pack(side="left", padx=(6, 0))

        self.run_btn = ctk.CTkButton(bottom, text="▶  Analizuj", height=46, font=(FONT, 16, "bold"),
                                     fg_color=ACCENT, hover_color=ACCENT_H, text_color="#111111", corner_radius=12,
                                     command=self._run)
        self.run_btn.pack(fill="x", padx=14, pady=(10, 6))
        self.progress = ctk.CTkProgressBar(bottom, progress_color=ACCENT, height=8)
        self.progress.set(0)
        self.progress.pack(fill="x", padx=14)
        self.status = ctk.CTkLabel(bottom, text="Gotowy", text_color=MUTED, font=(FONT, 11))
        self.status.pack(anchor="w", padx=14, pady=(4, 0))
        ctk.CTkButton(bottom, text="Otwórz folder wyników", fg_color=CARD, hover_color=BORDER, text_color=TEXT,
                      command=self._open_out).pack(fill="x", padx=14, pady=(8, 12))

        # --- główny obszar: kafelki
        cards = ctk.CTkFrame(main, fg_color="transparent")
        cards.pack(fill="x")
        for i in range(2):
            cards.grid_columnconfigure(i, weight=1, uniform="c")
        self.card_hot = StatCard(cards, "Najcieplejszy punkt twarzy", C_HOT)
        self.card_time = StatCard(cards, "Czas filmu", MUTED)
        for i, c in enumerate((self.card_hot, self.card_time)):
            c.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 10, 0))
        self.alarm = AlarmBanner(cards)
        self.alarm.grid(row=1, column=0, columnspan=2, sticky="nsew", pady=(10, 0))

        # podgląd + odtwarzacz
        viewer = ctk.CTkFrame(main, fg_color=PANEL, corner_radius=14)
        viewer.pack(fill="both", expand=True, pady=12)
        self.screen = tk.Label(viewer, bg="#0a0b0e", bd=0, fg=MUTED, font=(FONT, 13),
                               text="Wybierz plik i kliknij „Analizuj”.\n"
                                    "Wynik – zdjęcie albo film z zaznaczoną twarzą – pojawi się tutaj.")
        self.screen.pack(fill="both", expand=True, padx=10, pady=(10, 6))
        self.screen.bind("<Configure>", lambda e: self._refresh_view())

        ctrl = ctk.CTkFrame(viewer, fg_color="transparent")
        ctrl.pack(fill="x", padx=10, pady=(0, 10))
        self.ctrl = ctrl
        self.play_btn = ctk.CTkButton(ctrl, text="▶", width=44, height=36, font=(FONT, 16),
                                      fg_color=ACCENT, hover_color=ACCENT_H, text_color="#111111",
                                      command=self._toggle_play, state="disabled")
        self.play_btn.pack(side="left")
        ctk.CTkButton(ctrl, text="◀", width=36, height=36, fg_color=CARD, hover_color=BORDER, text_color=TEXT,
                      command=lambda: self._step(-1)).pack(side="left", padx=(6, 0))
        ctk.CTkButton(ctrl, text="▶|", width=36, height=36, fg_color=CARD, hover_color=BORDER, text_color=TEXT,
                      command=lambda: self._step(1)).pack(side="left", padx=(4, 8))
        self.slider = ctk.CTkSlider(ctrl, from_=0, to=1, number_of_steps=1, command=self._on_slider,
                                    button_color=ACCENT, button_hover_color=ACCENT_H, progress_color=ACCENT)
        self.slider.set(0)
        self.slider.pack(side="left", fill="x", expand=True, padx=6)
        self.time_lbl = ctk.CTkLabel(ctrl, text="0.0 / 0.0 s", width=110, text_color=MUTED, font=(FONT, 12))
        self.time_lbl.pack(side="left")
        self.speed = ctk.CTkOptionMenu(ctrl, values=["0.25×", "0.5×", "1×", "2×"], width=80,
                                       fg_color=CARD, button_color=CARD, button_hover_color=BORDER)
        self.speed.set("1×")
        self.speed.pack(side="left", padx=(8, 0))

        # dół: wykres / sekundy / szczegóły
        tabs = ctk.CTkTabview(main, height=240, fg_color=PANEL, segmented_button_selected_color=ACCENT,
                              segmented_button_selected_hover_color=ACCENT_H)
        tabs.pack(fill="x")
        self.tabs = tabs
        t1, t2, t3 = tabs.add("Wykres w czasie"), tabs.add("Sekunda po sekundzie"), tabs.add("Szczegóły")
        self.chart = Chart(t1, self._seek_time)
        self.chart.pack(fill="both", expand=True)

        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("T.Treeview", background=CARD, fieldbackground=CARD, foreground=TEXT, rowheight=24,
                        borderwidth=0, font=(FONT, 10))
        style.configure("T.Treeview.Heading", background=PANEL, foreground=MUTED, borderwidth=0, font=(FONT, 10, "bold"))
        style.map("T.Treeview", background=[("selected", ACCENT)], foreground=[("selected", "#111111")])
        cols = ("sek", "hot", "twarz", "metoda")  # "twarz": klatki z twarzą / klatka pomiaru
        self.table = ttk.Treeview(t2, columns=cols, show="headings", style="T.Treeview", height=6)
        for c, txt, w in zip(cols, ("Sekunda", "Najcieplejszy punkt [°C]", "Pomiar (klatka, pewność)",
                                    "Wykrycie twarzy"),
                             (80, 230, 230, 180)):
            self.table.heading(c, text=txt)
            self.table.column(c, width=w, anchor="center")
        self.table.pack(fill="both", expand=True)
        self.table.bind("<<TreeviewSelect>>", self._on_table)
        self.logbox = ctk.CTkTextbox(t3, fg_color=CARD, text_color=TEXT, font=(FONT, 11), wrap="word")
        self.logbox.pack(fill="both", expand=True)

    def _section(self, parent, title, collapsed=False):
        wrap = ctk.CTkFrame(parent, fg_color=CARD, corner_radius=12, border_width=1, border_color=BORDER)
        wrap.pack(fill="x", padx=14, pady=6)
        body = ctk.CTkFrame(wrap, fg_color="transparent")
        hdr = ctk.CTkButton(wrap, text=("▸  " if collapsed else "▾  ") + title, anchor="w", fg_color="transparent",
                            hover_color=BORDER, text_color=TEXT, font=(FONT, 13, "bold"), height=30)
        hdr.pack(fill="x", padx=6, pady=(6, 0))

        def toggle():
            if body.winfo_ismapped():
                body.pack_forget()
                hdr.configure(text="▸  " + title)
            else:
                body.pack(fill="x", padx=12, pady=(2, 10))
                hdr.configure(text="▾  " + title)
        hdr.configure(command=toggle)
        if not collapsed:
            body.pack(fill="x", padx=12, pady=(2, 10))
        return body

    def _file_row(self, parent, label, key):
        ctk.CTkLabel(parent, text=label, font=(FONT, 11), text_color=MUTED).pack(anchor="w", pady=(4, 0))
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x")
        ctk.CTkEntry(row, textvariable=self.vars[key]).pack(side="left", fill="x", expand=True)
        ctk.CTkButton(row, text="Wybierz", width=70, fg_color=BORDER, hover_color="#363c4a", text_color=TEXT,
                      command=lambda: self.vars[key].set(filedialog.askopenfilename(filetypes=FILETYPES) or self.vars[key].get())
                      ).pack(side="left", padx=(6, 0))

    def _param_rows(self, grid, rows):
        for i, (lbl, key, choices, ph) in enumerate(rows):
            ctk.CTkLabel(grid, text=lbl, font=(FONT, 12), text_color=TEXT).grid(row=i, column=0, sticky="w", pady=3)
            if choices:
                w = ctk.CTkOptionMenu(grid, variable=self.vars[key], values=choices, width=120, dynamic_resizing=False,
                                      fg_color=BORDER, button_color=BORDER, button_hover_color="#363c4a")
            else:
                w = ctk.CTkEntry(grid, textvariable=self.vars[key], width=120)
                if ph:
                    ctk.CTkLabel(grid, text=ph if not self.vars[key].get() else "", font=(FONT, 10),
                                 text_color=MUTED).grid(row=i, column=2, sticky="w", padx=(6, 0))
            w.grid(row=i, column=1, sticky="e", padx=(8, 0), pady=3)

    # ---------------------------------------------------------------- pomocnicze
    def _pick_out(self):
        d = filedialog.askdirectory()
        if d:
            self.vars["out"].set(d)

    def _open_out(self):
        d = self.vars["out"].get()
        if os.path.isdir(d) and hasattr(os, "startfile"):
            os.startfile(d)

    def log(self, s):
        self.logbox.insert("end", s)
        self.logbox.see("end")

    # ------------------------------------------------------------------ analiza
    def _argv(self):
        v = {k: x.get().strip() for k, x in self.vars.items()}
        argv = []
        if not v["color"]:
            raise ValueError("Wybierz zdjęcie FLIR albo film z kamery.")
        argv += ["--color", v["color"]]
        for key, opt in [("tmin", "--tmin"), ("tmax", "--tmax"), ("emissivity", "--emissivity"),
                         ("distance", "--distance"), ("core_offset", "--core-offset"), ("body_tmin", "--body-tmin")]:
            if not v[key]:
                continue
            float(v[key].replace(",", "."))
            argv += [opt, v[key].replace(",", ".")]
        argv += ["--step", str(max(1, int(v["step"] or 1))), "--palette", v["palette"],
                 "--gray-invert", v["gray_invert"], "--out", v["out"],
                 "--tryb-sekundy", "pewna" if v["tryb"] == TRYB_PEWNA else "srednia",
                 "--pewnosc", str(min(1.0, max(0.0, float((v["pewnosc"] or "0.6").replace(",", "."))))),
                 "--pomin", str(max(0, int(float((v["pomin"] or "30").replace(",", "."))))),
                 "--pomin-bez-twarzy", str(max(0, int(float((v["pomin_bt"] or "0").replace(",", ".")))))]
        yunet = os.path.join(_base_dir(), "face_detection_yunet_2023mar.onnx")
        if os.path.exists(yunet):
            argv += ["--yunet", yunet]
        return argv

    def _run(self):
        try:
            argv = self._argv()
        except ValueError as e:
            messagebox.showerror("Błąd parametrów", str(e) if "could not" not in str(e) else "Liczby wpisz w formacie np. 36.5")
            return
        self._stop_video()
        self.logbox.delete("1.0", "end")
        self.run_btn.configure(state="disabled", text="Analiza w toku…")
        self.progress.configure(mode="indeterminate")
        self.progress.start()
        self.status.configure(text="Analizuję…")
        threading.Thread(target=self._worker, args=(argv,), daemon=True).start()

    def _progress(self, done, total):
        def upd():
            if total:
                if self.progress.cget("mode") != "determinate":
                    self.progress.stop()
                    self.progress.configure(mode="determinate")
                self.progress.set(min(1.0, done / total))
                self.status.configure(text=f"Klatka {done} z {total}")
            else:
                self.status.configure(text=f"Przeanalizowano klatek: {done}")
        self.after(0, upd)

    def _worker(self, argv):
        old = sys.stdout
        sys.stdout = _TextRedirect(self)
        try:
            report = ta.main(argv, progress=self._progress)
            self.after(0, self._done, report)
        except SystemExit as e:
            self.after(0, self._fail, str(e))
        except Exception:
            self.after(0, self._fail, traceback.format_exc())
        finally:
            sys.stdout = old

    def _end_busy(self):
        self.progress.stop()
        self.progress.configure(mode="determinate")
        self.run_btn.configure(state="normal", text="▶  Analizuj")

    def _fail(self, msg):
        self._end_busy()
        self.progress.set(0)
        self.status.configure(text="Błąd analizy – szczegóły w zakładce „Szczegóły”")
        self.log("\n" + msg)

    def _done(self, report):
        self._end_busy()
        self.progress.set(1)
        self.status.configure(text="Gotowe")
        s = report["podsumowanie"]
        self.summary = s
        self.frames_data = report.get("klatki") or []
        self.seconds = {d["sekunda"]: d for d in report.get("sekundy") or []}
        self.notes = report.get("uwagi") or []
        fmt = lambda v, ge=False: "–" if v is None else ("≥ " if ge else "") + f"{v:.1f} °C"  # noqa: E731
        hot = s.get("najcieplejszy_punkt_twarzy")
        sub = "nie znaleziono twarzy" if hot is None else ""
        if s["klatek"] > 1:
            if hot is None:
                sub = ("brak sekund z pewną twarzą" if s.get("tryb_sekundy") == "pewna" else "nie znaleziono twarzy")
            else:
                sub = (f"średnia z {s.get('sekund_z_wynikiem')} s · maks. {s['najcieplejszy_punkt_twarzy_max']:.1f} °C "
                       f"w {s['najcieplejszy_punkt_twarzy_czas_s']:.1f} s")
        self.card_hot.set(fmt(hot, s.get("najcieplejszy_punkt_twarzy_poza_skala") and s["klatek"] == 1), sub)
        out = self.vars["out"].get()
        mp4 = os.path.join(out, "adnotacje.mp4")
        png = os.path.join(out, "adnotacje.png")
        self._fill_table()
        self._update_alarm()
        if s["klatek"] > 1 and os.path.exists(mp4):
            self._load_video(mp4)
        elif os.path.exists(png):
            f0 = self.frames_data[0] if self.frames_data else {}
            self.card_time.set("Zdjęcie", f"twarz: {f0.get('metoda_twarzy') or 'nie znaleziono'}", title="Rodzaj")
            self._show_still(png)

    # ------------------------------------------------------------ alarm temperatury
    def _measurements(self):
        """Pomiary najcieplejszego punktu twarzy: w filmie wyniki kolejnych sekund, w zdjęciu jeden pomiar.
        Zwraca listę (wartość, czy_koniec_skali)."""
        if self.seconds:
            return [(d["najcieplejszy_punkt_twarzy"], bool(d.get("twarz_max_poza_skala")))
                    for _, d in sorted(self.seconds.items()) if d.get("najcieplejszy_punkt_twarzy") is not None]
        return [(f["twarz_max"], bool(f.get("twarz_max_poza_skala")))
                for f in self.frames_data if f.get("twarz_max") is not None]

    def _update_alarm(self):
        if not hasattr(self, "alarm"):
            return
        try:
            prog = float((self.vars["alarm_prog"].get() or "37.5").replace(",", "."))
            ile = max(1, int(float((self.vars["alarm_ile"].get() or "2").replace(",", "."))))
        except ValueError:
            self.alarm.set(None, "Ocena temperatury", "popraw próg alarmu albo liczbę pomiarów w ustawieniach")
            return
        if not self.frames_data:
            self.alarm.set(None, "Ocena temperatury – brak wyniku", "wybierz plik i kliknij „Analizuj”")
            return
        ms = self._measurements()
        no_yolo = any("Brak modelu YOLO" in n or "YOLO niedostępne" in n for n in getattr(self, "notes", []))
        if no_yolo and not ms:
            self.alarm.set("warn", "⚠  Brak modelu YOLO",
                           "brak pliku yolov8n-face.onnx, więc nie ma pomiarów\n"
                           "połóż go obok build_exe.bat i zbuduj exe ponownie")
            return
        if not ms:
            self.alarm.set(None, "Brak pomiaru", "nie znaleziono twarzy – nie można ocenić temperatury")
            return
        need = min(ile, len(ms)) if len(self.frames_data) == 1 else ile  # zdjęcie = jeden pomiar
        above = [v for v, _ in ms if v > prog]
        ps = f"{prog:.1f}".replace(".", ",")
        word = "pomiar" if len(ms) == 1 else ("pomiary" if 2 <= len(ms) % 10 <= 4 and not 12 <= len(ms) % 100 <= 14 else "pomiarów")
        sub = (f"{len(above)} z {len(ms)} {word} twarzy powyżej {ps} °C (alarm od {need})\n"
               f"najwyżej {max(v for v, _ in ms):.1f} °C".replace(".", ","))
        if len(above) >= need:
            self.alarm.set("alarm", "⚠  WYSOKA TEMPERATURA", sub)
        else:
            cut = sum(1 for v, ge in ms if ge and v <= prog)
            if cut:
                sub += f" · {cut} na końcu skali kamery (może być więcej)"
            self.alarm.set("ok", "✓  Temperatura w normie", sub)

    # ------------------------------------------------------------ tabela / wykres
    def _fill_table(self):
        self.table.delete(*self.table.get_children())
        fr = self.frames_data
        if not fr:
            self.chart.set_data([], [])
            return
        if len(fr) == 1:
            f = fr[0]
            self.chart.set_data([], [])
            ge = "≥ " if f.get("twarz_max_poza_skala") and f.get("twarz_max") is not None else ""
            self.table.insert("", "end", iid="0", values=(
                "zdjęcie", ge + self._f(f.get("twarz_max")),
                (f"pewność {f['pewnosc_twarzy']:.2f}" if f.get("pewnosc_twarzy") is not None
                 else ("twarz bez oceny pewności" if f.get("twarz") else "brak twarzy")),
                f.get("metoda_twarzy") or "–"))
            return
        # wykres i tabela: jedna wartość na sekundę = średnia ze wszystkich klatek tej sekundy
        secs = sorted(self.seconds)
        self.chart.set_data([s + 0.5 for s in secs], [self.seconds[s]["najcieplejszy_punkt_twarzy"] for s in secs])
        for sec in secs:
            d = self.seconds[sec]
            ge_h = "≥ " if d.get("twarz_max_poza_skala") and d["najcieplejszy_punkt_twarzy"] is not None else ""
            if d.get("tryb") == "pewna":
                pm = d.get("pewnosc_max")
                src = (f"kl. {d['klatka_pomiaru']} · {d['pewnosc_twarzy']:.2f}" if d.get("klatka_pomiaru") is not None
                       else ("brak twarzy" if pm is None else f"za mało · {pm:.2f}"))
            else:
                src = f"średnia z {d['klatek_z_twarza']}/{d['klatek']} kl."
            self.table.insert("", "end", iid=str(sec), values=(
                f"{sec} s", ge_h + self._f(d["najcieplejszy_punkt_twarzy"]), src,
                d.get("metoda_twarzy") or ("poniżej progu" if d.get("pewnosc_max") is not None else "brak twarzy")))

    @staticmethod
    def _f(v):
        return "–" if v is None else f"{v:.2f}"

    def _on_table(self, _e):
        sel = self.table.selection()
        if sel and self.cap is not None:
            self._seek_time(float(sel[0]))

    # ----------------------------------------------------------------- odtwarzacz
    def _video_mode(self, on: bool):
        """Film: pasek odtwarzacza i wykres. Zdjęcie: sam obraz z wynikami na całej wysokości."""
        if on:
            if not self.ctrl.winfo_ismapped():
                self.ctrl.pack(fill="x", padx=10, pady=(0, 10))
            if not self.tabs.winfo_ismapped():
                self.tabs.pack(fill="x")
            self.card_time.title_lbl.configure(text="Czas filmu")
        else:
            self.ctrl.pack_forget()
            self.tabs.pack_forget()

    def _load_video(self, path):
        self._stop_video()
        self._video_mode(True)
        self.cap = cv2.VideoCapture(path)
        self.n_frames = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT) or len(self.frames_data))
        self.fps = self.cap.get(cv2.CAP_PROP_FPS) or 25.0
        self.slider.configure(to=max(1, self.n_frames - 1), number_of_steps=max(1, self.n_frames - 1))
        self.play_btn.configure(state="normal")
        self.cur = 0
        self._show_frame(0)
        self._toggle_play()

    def _stop_video(self):
        self.playing = False
        self.play_btn.configure(text="▶")
        if self.cap is not None:
            self.cap.release()
        self.cap = None

    def _toggle_play(self):
        if self.cap is None:
            return
        self.playing = not self.playing
        self.play_btn.configure(text="❚❚" if self.playing else "▶")
        if self.playing:
            if self.cur >= self.n_frames - 1:
                self._show_frame(0)
            self._tick()

    def _tick(self):
        if not self.playing or self.cap is None:
            return
        nxt = self.cur + 1
        if nxt >= self.n_frames:
            self.playing = False
            self.play_btn.configure(text="▶")
            return
        self._show_frame(nxt, sequential=True)
        sp = float(self.speed.get().replace("×", ""))
        self.after(max(1, int(1000 / (self.fps * sp))), self._tick)

    def _step(self, d):
        if self.cap is None:
            return
        self.playing = False
        self.play_btn.configure(text="▶")
        self._show_frame(min(max(0, self.cur + d), self.n_frames - 1))

    def _on_slider(self, v):
        if self.cap is None or self._seeking:
            return
        self._show_frame(int(round(v)))

    def _seek_time(self, t):
        if self.cap is None:
            return
        self._show_frame(min(self.n_frames - 1, max(0, int(round(t * self.fps)))))

    def _show_frame(self, idx, sequential=False):
        if not sequential or idx != self.cur + 1:
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ok, frame = self.cap.read()
        if not ok:
            return
        self.cur = idx
        self._still = frame
        self._refresh_view()
        self._seeking = True
        self.slider.set(idx)
        self._seeking = False
        t = idx / self.fps
        self.time_lbl.configure(text=f"{t:.1f} / {max(0, self.n_frames - 1) / self.fps:.1f} s")
        if self.frames_data:
            # klatki przeanalizowane szukamy po czasie: po pomiarze część klatek jest pomijana (wersja 0.10)
            if getattr(self, "_fidx_key", None) != (id(self.frames_data), self.fps):
                self._fidx = {int(round(fr["czas_s"] * self.fps)): fr for fr in self.frames_data
                              if fr.get("czas_s") is not None}
                self._fidx_key = (id(self.frames_data), self.fps)
            f = self._fidx.get(idx) or (self.frames_data[idx] if not self._fidx and idx < len(self.frames_data) else {})
            ft = f.get("czas_s")
            ft = t if ft is None else ft
            self.chart.set_cursor(ft)
            sec = int(ft)
            d = self.seconds.get(sec)
            if d is not None:
                # wartości zmieniają się co sekundę
                ho = d["najcieplejszy_punkt_twarzy"]
                sat_h = d.get("twarz_max_poza_skala")
                if d.get("tryb") == "pewna":
                    where = (f"{sec}–{sec + 1} s · kl. {d['klatka_pomiaru']}, pewność {d['pewnosc_twarzy']:.2f}"
                             if d.get("klatka_pomiaru") is not None else f"{sec}–{sec + 1} s")
                else:
                    where = f"średnia z {sec}–{sec + 1} s"
            else:
                ho = f.get("twarz_max")
                sat_h = f.get("twarz_max_poza_skala")
                where = f"w {ft:.1f} s"
            sub = where
            if self.summary.get("najcieplejszy_punkt_twarzy_max") is not None:
                sub += f" · maks. filmu {self.summary['najcieplejszy_punkt_twarzy_max']:.1f} °C"
            if sat_h:
                sub = where + " · koniec skali"
            if ho is None:
                sub = ("brak pewnej twarzy w tej sekundzie" if d is not None and d.get("tryb") == "pewna"
                       else "brak twarzy w tej sekundzie")
                held = self._last_measurement(sec, ft)
                if held is not None:  # w czasie bez pomiaru kafelek pokazuje ostatni pomiar, jeśli nie był dawno
                    d2, tm = held
                    ho, sat_h = d2["najcieplejszy_punkt_twarzy"], d2.get("twarz_max_poza_skala")
                    kl = f", kl. {d2['klatka_pomiaru']}" if d2.get("klatka_pomiaru") is not None else ""
                    sub = f"ostatni pomiar: {tm:.1f} s{kl} ({max(0.0, ft - tm):.1f} s temu)"
            self.card_hot.set("–" if ho is None else ("≥ " if sat_h else "") + f"{ho:.1f} °C", sub)
            self.card_time.set(f"{ft:.1f} s", f"kl. {idx + 1} · " + self._conf_text(d, f))

    def _conf_text(self, d, f):
        """Pewność twarzy w tej sekundzie filmu (najwyższa z przeanalizowanych klatek, także poniżej progu)."""
        pm = d.get("pewnosc_max") if d is not None else f.get("pewnosc_twarzy")
        if d is not None and "pewnosc_max" not in d:  # wynik ze starszej wersji programu
            pm = d.get("pewnosc_twarzy")
        if pm is None:
            return "brak twarzy"
        try:
            prog = float((self.vars["pewnosc"].get() or "0.6").replace(",", "."))
        except ValueError:
            prog = 0.6
        return f"pewność twarzy {pm:.2f}".replace(".", ",") + ("" if pm >= prog else " (za mało)")

    def _last_measurement(self, sec, ft):
        """Ostatni wcześniejszy pomiar najcieplejszego punktu twarzy, jeśli był nie dawniej niż „Pokaż ost. pomiar”."""
        try:
            lim = float((self.vars["trzymaj"].get() or "0").replace(",", "."))
        except ValueError:
            lim = 5.0
        if lim <= 0:
            return None
        for s2 in range(sec - 1, -1, -1):
            d2 = self.seconds.get(s2)
            if d2 is not None and d2.get("najcieplejszy_punkt_twarzy") is not None:
                tm = d2.get("czas_pomiaru_s")
                tm = float(s2) if tm is None else float(tm)
                return (d2, tm) if ft - tm <= lim else None
            if ft - (s2 + 1) > lim:
                return None
        return None

    def _show_still(self, path):
        self._stop_video()
        img = cv2.imdecode(np.fromfile(path, np.uint8), cv2.IMREAD_COLOR)
        if img is None:
            return
        self._still = img
        self._video_mode(False)
        self.after(50, self._refresh_view)  # po zmianie układu podgląd jest większy

    def _refresh_view(self):
        if self._still is None:
            return
        W = max(100, self.screen.winfo_width() - 4)
        H = max(80, self.screen.winfo_height() - 4)
        img = self._still
        s = min(W / img.shape[1], H / img.shape[0])
        img = cv2.resize(img, (max(1, int(img.shape[1] * s)), max(1, int(img.shape[0] * s))),
                         interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_LINEAR)
        self._photo = ImageTk.PhotoImage(Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)))
        self.screen.configure(image=self._photo, text="")


if __name__ == "__main__":
    App().mainloop()
